import React, { useState, useEffect } from 'react';
import { 
  Smartphone, 
  Monitor, 
  Download, 
  CheckCircle2, 
  X, 
  ExternalLink, 
  HelpCircle, 
  Share2, 
  Copy, 
  Check, 
  QrCode, 
  Send, 
  Sparkles, 
  ShieldCheck, 
  PackageCheck,
  FileCode,
  Layers,
  Terminal
} from 'lucide-react';
import QRCode from 'qrcode';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  lang: 'hi' | 'en';
  onOpenVideoModal?: () => void;
}

export const PWAInstallModal: React.FC<Props> = ({ isOpen, onClose, lang, onOpenVideoModal }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'phone' | 'pc'>('phone');
  const [copied, setCopied] = useState(false);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');

  // Use the active working origin URL where the app is currently running
  const appUrl = typeof window !== 'undefined' && window.location.origin && window.location.origin !== 'null'
    ? window.location.origin
    : 'https://ais-dev-4h62udvptkklvqexdr2oip-395762312349.asia-northeast1.run.app';

  useEffect(() => {
    if (isOpen && appUrl) {
      QRCode.toDataURL(appUrl, {
        width: 220,
        margin: 1.5,
        color: {
          dark: '#0f172a',
          light: '#ffffff',
        },
      })
        .then(url => setQrCodeDataUrl(url))
        .catch(err => console.error('Failed to generate QR code', err));
    }
  }, [isOpen, appUrl]);

  if (!isOpen) return null;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleShareToWhatsApp = () => {
    const text = lang === 'hi'
      ? `🚗 बीमा रक्षक (BimaAlert) - मोटर पॉलिसी एक्सपायरी रिमाइंडर ऐप को इंस्टॉल करने के लिए इस लिंक पर क्लिक करें:\n${appUrl}\n\n(फोन या कंप्यूटर के Chrome ब्राउज़र में खोलकर 'Install App' दबाएं)`
      : `🚗 Install BimaAlert - Motor Policy Expiry Reminder App:\n${appUrl}\n\n(Open in Chrome & tap 'Install App')`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleInstallClick = async () => {
    const success = await install();
    if (success) {
      onClose();
    }
  };

  const handleDownloadWindowsShortcut = () => {
    // Generates a Windows desktop Internet Shortcut (.url) configured for app-mode
    const shortcutContent = `[InternetShortcut]\nURL=${appUrl}\nIconIndex=0\nIconFile=${appUrl}/icon.svg\n`;
    const blob = new Blob([shortcutContent], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'BimaAlert - Motor Insurance.url';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl p-5 sm:p-7 text-slate-100 my-6">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3.5 mb-5 pb-4 border-b border-slate-800">
          <div className="p-3 bg-gradient-to-br from-blue-600 via-indigo-600 to-teal-500 text-white rounded-2xl shadow-lg shadow-blue-500/20">
            {activeTab === 'pc' ? <Monitor className="w-6 h-6" /> : <Smartphone className="w-6 h-6" />}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xl font-bold text-white">
                {lang === 'hi' ? 'ऐप डाउनलोड व इंस्टॉलेशन सेंटर' : 'App Download & Install Center'}
              </h3>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {lang === 'hi' 
                ? 'मोबाइल (Android APK) एवं कंप्यूटर (Windows PC .EXE / Desktop App)' 
                : 'For Android Mobile (APK) and Windows PC (.EXE / Desktop App)'}
            </p>
          </div>
        </div>

        {/* Device Switcher Tabs: Phone vs Computer/PC */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-slate-800/80 rounded-2xl border border-slate-700/80 mb-5 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('phone')}
            className={`py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition ${
              activeTab === 'phone'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>{lang === 'hi' ? '📱 मोबाइल (Android APK)' : '📱 Mobile (Android APK)'}</span>
          </button>

          <button
            onClick={() => setActiveTab('pc')}
            className={`py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition ${
              activeTab === 'pc'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Monitor className="w-4 h-4" />
            <span>{lang === 'hi' ? '💻 कंप्यूटर / PC (.EXE)' : '💻 Computer / PC (.EXE)'}</span>
          </button>
        </div>

        {/* Watch Video Banner Button */}
        {onOpenVideoModal && (
          <button
            onClick={() => { onClose(); onOpenVideoModal(); }}
            className="w-full mb-4 py-2.5 px-4 rounded-2xl bg-gradient-to-r from-red-600/20 via-rose-600/20 to-red-600/20 hover:from-red-600/30 hover:to-rose-600/30 border border-red-500/40 text-red-300 flex items-center justify-between text-xs font-bold transition group"
          >
            <div className="flex items-center gap-2">
              <span className="p-1 rounded-lg bg-red-600 text-white text-xs">🎥</span>
              <span>{lang === 'hi' ? 'डाउनलोड करने का वीडियो ट्यूटोरियल देखें' : 'Watch How to Download Video Tutorial'}</span>
            </div>
            <span className="text-[11px] underline text-red-400 group-hover:text-red-200">
              {lang === 'hi' ? 'वीडियो चलाएं →' : 'Play Video →'}
            </span>
          </button>
        )}

        {/* Tab 1: Android Phone Installation */}
        {activeTab === 'phone' && (
          <div className="space-y-4">
            {/* Status Box if already running in standalone */}
            {isInstalled && (
              <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 flex items-center gap-3 text-emerald-300 text-xs">
                <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-400" />
                <div>
                  {lang === 'hi' 
                    ? 'यह ऐप पहले से आपके डिवाइस में स्थापित है और ऐप मोड में चल रही है।' 
                    : 'App is installed and running in native standalone mode.'}
                </div>
              </div>
            )}

            {/* 1-Click Install Button if in a Chromium browser */}
            {isInstallable && (
              <div className="p-4 rounded-2xl bg-blue-950/50 border border-blue-500/40 text-center">
                <p className="text-xs text-blue-200 mb-2.5 font-medium">
                  {lang === 'hi' 
                    ? 'आपका ब्राउज़र 1-क्लिक डायरेक्ट इंस्टॉल सपोर्ट करता है:' 
                    : 'Your browser supports 1-click install:'}
                </p>
                <button
                  onClick={handleInstallClick}
                  className="w-full py-3 px-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm rounded-xl shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transition active:scale-95"
                >
                  <Download className="w-4 h-4" />
                  <span>{lang === 'hi' ? '📲 अभी डिवाइस में ऐप इंस्टॉल करें' : '📲 Install App Now'}</span>
                </button>
              </div>
            )}

            {/* QR Code + Phone Link Section */}
            <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-4">
              <div className="flex flex-col sm:flex-row items-center gap-5">
                {/* Scannable QR Code */}
                {qrCodeDataUrl ? (
                  <div className="shrink-0 p-2.5 bg-white rounded-2xl shadow-xl flex flex-col items-center">
                    <img
                      src={qrCodeDataUrl}
                      alt="QR Code to Install APK on Phone"
                      className="w-36 h-36 sm:w-40 sm:h-40 rounded-lg object-contain"
                    />
                    <span className="text-[10px] text-slate-700 font-bold mt-1.5 flex items-center gap-1">
                      <QrCode className="w-3 h-3 text-blue-600" />
                      {lang === 'hi' ? 'फोन कैमरा से स्कैन करें' : 'Scan with Phone Camera'}
                    </span>
                  </div>
                ) : (
                  <div className="w-36 h-36 bg-slate-700 rounded-2xl animate-pulse shrink-0" />
                )}

                {/* Direct Link and Quick Action Buttons */}
                <div className="space-y-3 flex-1 text-center sm:text-left w-full">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      {lang === 'hi' ? '🔗 फोन इंस्टॉल लिंक:' : '🔗 Phone Install Link:'}
                    </label>
                    <div className="flex items-center gap-1.5 p-2 rounded-xl bg-slate-900 border border-slate-700 text-xs font-mono text-emerald-400 select-all overflow-x-auto">
                      <span className="truncate">{appUrl}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={handleCopyLink}
                      className="py-2.5 px-3 rounded-xl bg-slate-700 hover:bg-slate-600 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition active:scale-95"
                    >
                      {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                      <span>{copied ? (lang === 'hi' ? 'कॉपी हो गया!' : 'Copied!') : (lang === 'hi' ? 'लिंक कॉपी करें' : 'Copy Link')}</span>
                    </button>

                    <button
                      onClick={handleShareToWhatsApp}
                      className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/30 transition active:scale-95"
                    >
                      <Send className="w-4 h-4" />
                      <span>{lang === 'hi' ? 'व्हाट्सएप पर भेजें' : 'Send to WhatsApp'}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Clarification for PWABuilder */}
            <div className="p-3.5 rounded-xl bg-amber-950/40 border border-amber-500/40 flex items-start gap-2.5 text-xs text-amber-200">
              <HelpCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span className="font-semibold text-white">
                  {lang === 'hi' ? '⚠️ PWABuilder पर "Web Manifest Error" क्यों आता है?' : '⚠️ Why does PWABuilder show an error?'}
                </span>
                <p className="text-amber-200/90 text-[11px] leading-relaxed">
                  {lang === 'hi' 
                    ? 'Google AI Studio के लिंक आपके निजी Google अकाउंट से सुरक्षित होते हैं। PWABuilder एक बाहरी ऑटोमेटेड बॉट है जिसे Google सिक्योरिटी ब्लॉक कर देती है। आपको PWABuilder की कोई ज़रूरत नहीं है—ऊपर दिए गए QR कोड या लिंक को सीधे अपने फोन के Chrome ब्राउज़र में खोलें और 1-क्लिक में इंस्टॉल करें!' 
                    : 'AI Studio preview links are protected by Google Authentication. External bots like PWABuilder cannot access them. You do not need PWABuilder—open this link directly in mobile Chrome and tap "Install App"!'}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Windows PC / Computer .EXE & Desktop App */}
        {activeTab === 'pc' && (
          <div className="space-y-4">
            {/* Quick 1-Click Desktop Launcher (.url / .lnk) */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-950/60 via-indigo-950/40 to-slate-900 border border-blue-500/40 space-y-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-blue-600 text-white">
                  <Monitor className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm">
                    {lang === 'hi' ? 'तरीका 1: कंप्यूटर डेस्कटॉप शॉर्टकट (.URL) डाउनलोड करें' : 'Method 1: Download Windows Desktop Launcher'}
                  </h4>
                  <p className="text-xs text-blue-200/80">
                    {lang === 'hi' ? 'सीधे डबल-क्लिक करके कंप्यूटर पर ऐप की तरह चलाएं' : 'Runs like native software directly on Windows PC'}
                  </p>
                </div>
              </div>

              <button
                onClick={handleDownloadWindowsShortcut}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 transition active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>{lang === 'hi' ? '⬇️ Windows डेस्कटॉप लॉन्चर डाउनलोड करें' : '⬇️ Download Desktop Launcher (.url)'}</span>
              </button>
            </div>

            {/* Method 2: Native Windows Chrome/Edge Desktop App Installation */}
            <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-3 text-xs">
              <div className="font-bold text-emerald-400 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>
                  {lang === 'hi' 
                    ? 'तरीका 2: Chrome या Edge से Windows Desktop App इंस्टॉल करें (सर्वश्रेष्ठ):' 
                    : 'Method 2: Install via Chrome or Edge on Windows (Best):'}
                </span>
              </div>

              <ol className="space-y-2 text-slate-300 list-decimal list-inside pl-1 leading-relaxed text-[11.5px]">
                <li>
                  {lang === 'hi' 
                    ? 'कंप्यूटर में Google Chrome या Microsoft Edge ब्राउज़र खोलें।' 
                    : 'Open Google Chrome or Microsoft Edge on your PC.'}
                </li>
                <li>
                  {lang === 'hi' 
                    ? 'ऊपर एड्रेस बार (Address Bar) में सबसे दाईं ओर देखें—वहां एक छोटा 🖥️ या ⬇️ "Install BimaAlert" का आइकन दिखेगा।' 
                    : 'Look at the top-right of your address bar for the "Install BimaAlert" icon (🖥️ or ⬇️).'}
                </li>
                <li>
                  {lang === 'hi' 
                    ? '"Install" पर क्लिक करें। यह तुरंत आपके कंप्यूटर के डेस्कटॉप पर आइकन और टास्कबार (Taskbar) में पिन हो जाएगी।' 
                    : 'Click "Install". It creates a desktop shortcut and pins to your Windows Taskbar.'}
                </li>
                <li>
                  {lang === 'hi' 
                    ? 'यह किसी भी .exe सॉफ्टवेयर की तरह बिना ब्राउज़र टैब के अलग विंडो में तेज चलेगी।' 
                    : 'Launches in its own standalone window just like native .exe software.'}
                </li>
              </ol>
            </div>

            {/* Native Windows vs PWABuilder Note */}
            <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/40 space-y-2 text-xs">
              <div className="font-bold text-amber-400 flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-amber-400" />
                <span>
                  {lang === 'hi' 
                    ? 'कंप्यूटर उपयोगकर्ताओं के लिए जरूरी सूचना:' 
                    : 'Important Note for PC Users:'}
                </span>
              </div>
              <p className="text-slate-300 text-[11.5px] leading-relaxed">
                {lang === 'hi' 
                  ? 'PWABuilder एक बाहरी वेबसाइट है जो Google के निजी सुरक्षा फ़ायरवॉल को पार नहीं कर सकती, इसलिए वहां "Web Manifest Error" आता है। आपको किसी बाहरी वेबसाइट की कोई आवश्यकता नहीं है—ऊपर दिए गए "तरीका 2" (Chrome/Edge एड्रेस बार में 🖥️ Install BimaAlert) से आप इसे 1 सेकंड में कंप्यूटर पर पूरी तरह असली सॉफ्टवेयर (.exe) की तरह इंस्टॉल कर सकते हैं!' 
                  : 'PWABuilder is an external crawler blocked by Google sandbox security. You do not need any external website—use Method 2 above (Click the 🖥️ Install icon in Chrome/Edge) to install it directly on Windows in 1 click!'}
              </p>
            </div>
          </div>
        )}

        <div className="mt-5 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium transition"
          >
            {lang === 'hi' ? 'समझ गया / बंद करें' : 'Got it / Close'}
          </button>
        </div>
      </div>
    </div>
  );
};

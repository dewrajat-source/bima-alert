import React, { useState } from 'react';
import { 
  X, 
  UserCheck, 
  Download, 
  Upload, 
  FileSpreadsheet, 
  Bell, 
  Check, 
  Smartphone, 
  Save, 
  MessageSquare,
  AlertTriangle,
  Database,
  FolderArchive
} from 'lucide-react';
import { AgentProfile } from '../types/policy';
import { StorageService } from '../services/storage';
import { downloadProjectZip } from '../utils/projectZip';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  agent: AgentProfile;
  onSaveAgent: (profile: AgentProfile) => void;
  lang: 'hi' | 'en';
  onRefreshPolicies: () => void;
}

export const SettingsModal: React.FC<Props> = ({
  isOpen,
  onClose,
  agent,
  onSaveAgent,
  lang,
  onRefreshPolicies,
}) => {
  const [profile, setProfile] = useState<AgentProfile>(agent);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [isZipping, setIsZipping] = useState(false);

  if (!isOpen) return null;

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      await downloadProjectZip();
    } catch (e) {
      console.error(e);
    } finally {
      setIsZipping(false);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveAgent(profile);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleDownloadBackup = () => {
    const json = StorageService.exportBackupJson();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bima-alert-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadCSV = () => {
    const csv = StorageService.exportToCSV();
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `motor-policies-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const res = StorageService.importBackupJson(content);
      if (res.success) {
        setImportStatus(lang === 'hi' ? `सफलतापूर्वक ${res.count} पॉलिसियां रिस्टोर हुईं!` : `Successfully restored ${res.count} policies!`);
        onRefreshPolicies();
      } else {
        setImportStatus(res.error || 'Failed to import');
      }
    };
    reader.readAsText(file);
  };

  const handleRequestNotification = async () => {
    if ('Notification' in window) {
      const perm = await Notification.requestPermission();
      if (perm === 'granted') {
        alert(lang === 'hi' ? 'नोटिफिकेशन अनुमति सक्रिय हो गई है!' : 'Notifications enabled successfully!');
      } else {
        alert(lang === 'hi' ? 'नोटिफिकेशन की अनुमति अस्वीकार कर दी गई।' : 'Notifications permission denied.');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-5 sm:p-6 text-slate-100 my-6">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5 pb-4 border-b border-slate-800">
          <div className="p-3 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/30">
            <UserCheck className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">
              {lang === 'hi' ? 'एजेंट प्रोफाइल एवं सेटिंग्स' : 'Agent Profile & Settings'}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {lang === 'hi' 
                ? 'व्हाट्सएप मैसेज में आपका नाम व एजेंसी विवरण दिखेगा।' 
                : 'Custom branding for WhatsApp reminder messages and backups.'}
            </p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Section 1: Agent Profile */}
          <form onSubmit={handleSave} className="space-y-3.5">
            <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-3">
              <h4 className="text-xs font-semibold text-blue-400 uppercase tracking-wider flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5" />
                <span>{lang === 'hi' ? '1. एजेंट / शॉप विवरण' : '1. Agent Details'}</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    {lang === 'hi' ? 'आपका नाम' : 'Your Name'}
                  </label>
                  <input
                    type="text"
                    required
                    value={profile.agentName}
                    onChange={(e) => setProfile({ ...profile, agentName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm outline-hidden focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    {lang === 'hi' ? 'एजेंसी / शॉप का नाम' : 'Agency / Shop Name'}
                  </label>
                  <input
                    type="text"
                    required
                    value={profile.agencyName}
                    onChange={(e) => setProfile({ ...profile, agencyName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm outline-hidden focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    {lang === 'hi' ? 'मोबाइल नंबर (कॉल हेतु)' : 'Mobile Phone'}
                  </label>
                  <input
                    type="tel"
                    required
                    value={profile.phone}
                    onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm outline-hidden focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    {lang === 'hi' ? 'शहर / स्थान' : 'City / Location'}
                  </label>
                  <input
                    type="text"
                    value={profile.city}
                    onChange={(e) => setProfile({ ...profile, city: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm outline-hidden focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between">
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-md shadow-blue-600/30 transition"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{lang === 'hi' ? 'प्रोफाइल सुरक्षित करें' : 'Save Profile'}</span>
                </button>

                {saveSuccess && (
                  <span className="text-xs text-emerald-400 font-medium flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" />
                    {lang === 'hi' ? 'प्रोफाइल सेव हो गई!' : 'Saved successfully!'}
                  </span>
                )}
              </div>
            </div>
          </form>

          {/* Section 2: Data Backup & CSV Export */}
          <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-3">
            <h4 className="text-xs font-semibold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
              <Database className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? '2. डाटा बैकअप और एक्सेल एक्सपोर्ट' : '2. Backup & Export'}</span>
            </h4>
            <p className="text-xs text-slate-400">
              {lang === 'hi' 
                ? 'अपने ग्राहकों के रिकॉर्ड को कभी न खोएं। नियमित बैकअप डाउनलोड करें या एक्सेल में खोलें।' 
                : 'Safeguard all policy data by downloading a local JSON or CSV spreadsheet.'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
              {/* Download JSON Backup */}
              <button
                onClick={handleDownloadBackup}
                className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-medium flex items-center justify-center gap-1.5 text-slate-200 transition"
              >
                <Download className="w-4 h-4 text-blue-400" />
                <span>{lang === 'hi' ? 'बैकअप डाउनलोड' : 'JSON Backup'}</span>
              </button>

              {/* Export to CSV */}
              <button
                onClick={handleDownloadCSV}
                className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-medium flex items-center justify-center gap-1.5 text-slate-200 transition"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                <span>{lang === 'hi' ? 'एक्सेल (CSV)' : 'Excel (CSV)'}</span>
              </button>

              {/* Import Backup */}
              <label className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-medium flex items-center justify-center gap-1.5 text-slate-200 transition cursor-pointer">
                <Upload className="w-4 h-4 text-amber-400" />
                <span>{lang === 'hi' ? 'बैकअप रिस्टोर' : 'Restore'}</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            {importStatus && (
              <p className="text-xs text-amber-300 mt-2 bg-amber-950/30 p-2 rounded-lg border border-amber-500/20">
                {importStatus}
              </p>
            )}

            {/* Download Full Source Code ZIP for GitHub/Vercel */}
            <div className="pt-2 border-t border-slate-700/60">
              <button
                type="button"
                onClick={handleDownloadZip}
                disabled={isZipping}
                className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-indigo-600 via-blue-600 to-indigo-600 hover:from-indigo-500 hover:to-blue-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-md shadow-indigo-600/30 transition active:scale-95 disabled:opacity-60 cursor-pointer"
              >
                <FolderArchive className="w-4 h-4" />
                <span>{isZipping ? (lang === 'hi' ? 'ZIP फाइल बन रही है...' : 'Generating ZIP...') : (lang === 'hi' ? '📦 पूरे प्रोजेक्ट का कोड (ZIP) डाउनलोड करें' : '📦 Download Project Source Code (ZIP)')}</span>
              </button>
              <p className="text-[11px] text-slate-400 mt-1 text-center">
                {lang === 'hi' ? 'GitHub या Vercel पर अपलोड करने के लिए 1-क्लिक पूरी कोड फाइल' : 'For 1-click upload to GitHub or Vercel'}
              </p>
            </div>
          </div>

          {/* Section 3: Browser Notifications */}
          <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-between gap-3">
            <div className="space-y-0.5">
              <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                <Bell className="w-3.5 h-3.5 text-amber-400" />
                <span>{lang === 'hi' ? 'ब्राउज़र पुश नोटिफिकेशन' : 'Browser Push Notifications'}</span>
              </div>
              <p className="text-[11px] text-slate-400">
                {lang === 'hi' 
                  ? '7 दिन के भीतर पॉलिसी एक्सपायर होने पर स्क्रीन पर पॉपअप सूचना पाएं।' 
                  : 'Receive system alerts when policies are expiring within 7 days.'}
              </p>
            </div>

            <button
              onClick={handleRequestNotification}
              className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-semibold transition shrink-0"
            >
              {lang === 'hi' ? 'अनुमति दें' : 'Enable'}
            </button>
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium transition"
          >
            {lang === 'hi' ? 'बंद करें' : 'Done'}
          </button>
        </div>
      </div>
    </div>
  );
};

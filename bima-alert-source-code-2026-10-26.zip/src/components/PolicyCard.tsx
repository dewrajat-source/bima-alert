import React, { useState } from 'react';
import { 
  Car, 
  Bike, 
  Truck, 
  Phone, 
  MessageCircle, 
  RefreshCw, 
  MoreVertical, 
  Edit3, 
  Trash2, 
  Clock, 
  Calendar, 
  CheckCircle2, 
  AlertTriangle, 
  Copy, 
  Check, 
  ChevronDown, 
  ChevronUp, 
  History,
  Shield,
  Send
} from 'lucide-react';
import { AgentProfile, Policy } from '../types/policy';
import { formatDateIndian, getDaysRemaining, getUrgencyBadgeInfo } from '../utils/reminderUtils';
import { buildWhatsAppMessage, getCallUrl, getWhatsAppUrl } from '../utils/whatsapp';

interface Props {
  policy: Policy;
  agent: AgentProfile;
  lang: 'hi' | 'en';
  onEdit: (policy: Policy) => void;
  onDelete: (id: string) => void;
  onRenew: (policy: Policy) => void;
  onMarkReminded: (id: string) => void;
}

export const PolicyCard: React.FC<Props> = ({
  policy,
  agent,
  lang,
  onEdit,
  onDelete,
  onRenew,
  onMarkReminded,
}) => {
  const [showHistory, setShowHistory] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showMenu, setShowMenu] = useState(false);

  const daysRemaining = getDaysRemaining(policy.policyExpiryDate);
  const urgency = getUrgencyBadgeInfo(daysRemaining, lang);

  const getVehicleIcon = () => {
    switch (policy.vehicleType) {
      case 'two_wheeler':
        return <Bike className="w-4 h-4" />;
      case 'commercial':
      case 'tractor':
        return <Truck className="w-4 h-4" />;
      case 'taxi':
      case 'four_wheeler':
      default:
        return <Car className="w-4 h-4" />;
    }
  };

  const handleWhatsAppClick = () => {
    onMarkReminded(policy.id);
    const url = getWhatsAppUrl(policy, agent, lang);
    window.open(url, '_blank');
  };

  const handleCopyMessage = () => {
    const text = buildWhatsAppMessage(policy, agent, lang);
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={`relative rounded-2xl bg-slate-800/90 border transition-all hover:shadow-xl ${urgency.borderClass} ${urgency.bgLightClass} overflow-hidden group`}>
      {/* Top Banner with Urgency Badge & Action Menu */}
      <div className="p-4 pb-3 flex items-start justify-between gap-3 border-b border-slate-700/50">
        {/* Vehicle Plate & Make/Model */}
        <div className="space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            {/* Number Plate Visual */}
            <div className="inline-flex items-center px-2.5 py-1 rounded-lg bg-amber-400 text-slate-950 font-mono font-black text-sm tracking-widest border border-amber-500 shadow-xs">
              <span className="text-[10px] mr-1.5 font-bold tracking-normal opacity-75">IND</span>
              <span>{policy.vehicleNumber}</span>
            </div>

            {/* Urgency Badge */}
            <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold border ${urgency.badgeClass}`}>
              {daysRemaining <= 0 ? (
                <AlertTriangle className="w-3.5 h-3.5" />
              ) : (
                <Clock className="w-3.5 h-3.5" />
              )}
              <span>{urgency.label}</span>
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-300 font-medium">
            <span className="text-slate-400">{getVehicleIcon()}</span>
            <span>{policy.vehicleMakeModel || (lang === 'hi' ? 'गाड़ी' : 'Vehicle')}</span>
            <span className="text-slate-600">•</span>
            <span className="capitalize text-slate-400">
              {policy.policyType === 'comprehensive' 
                ? (lang === 'hi' ? 'फुल पैकेज' : 'Comprehensive')
                : policy.policyType === 'third_party' 
                ? 'TP Only' 
                : 'OD'}
            </span>
          </div>
        </div>

        {/* Action Menu (Edit, Delete, Copy) */}
        <div className="relative">
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-700/80 transition"
          >
            <MoreVertical className="w-4 h-4" />
          </button>

          {showMenu && (
            <div className="absolute right-0 top-8 z-30 w-44 rounded-xl bg-slate-900 border border-slate-700 shadow-xl py-1 text-xs">
              <button
                onClick={() => { setShowMenu(false); onEdit(policy); }}
                className="w-full px-3 py-2 text-left hover:bg-slate-800 flex items-center gap-2 text-slate-300"
              >
                <Edit3 className="w-3.5 h-3.5 text-blue-400" />
                <span>{lang === 'hi' ? 'एडिट करें' : 'Edit Details'}</span>
              </button>
              <button
                onClick={() => { setShowMenu(false); handleCopyMessage(); }}
                className="w-full px-3 py-2 text-left hover:bg-slate-800 flex items-center gap-2 text-slate-300"
              >
                <Copy className="w-3.5 h-3.5 text-emerald-400" />
                <span>{lang === 'hi' ? 'मैसेज कॉपी करें' : 'Copy Message'}</span>
              </button>
              <button
                onClick={() => { setShowMenu(false); onRenew(policy); }}
                className="w-full px-3 py-2 text-left hover:bg-slate-800 flex items-center gap-2 text-emerald-400"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>{lang === 'hi' ? 'रिन्यू करें' : 'Renew Policy'}</span>
              </button>
              <div className="border-t border-slate-800 my-1" />
              <button
                onClick={() => { setShowMenu(false); onDelete(policy.id); }}
                className="w-full px-3 py-2 text-left hover:bg-rose-950/50 flex items-center gap-2 text-rose-400"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{lang === 'hi' ? 'डिलीट करें' : 'Delete'}</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Card Body with Customer and Expiry Details */}
      <div className="p-4 space-y-3">
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div>
            <span className="text-slate-400 block text-[11px]">{lang === 'hi' ? 'ग्राहक का नाम:' : 'Customer:'}</span>
            <span className="font-semibold text-white text-sm truncate block">{policy.customerName}</span>
            <span className="text-slate-400 text-[11px] block">{policy.customerPhone}</span>
          </div>

          <div className="text-right">
            <span className="text-slate-400 block text-[11px]">{lang === 'hi' ? 'समाप्ति तिथि (Expiry):' : 'Expiry Date:'}</span>
            <span className={`font-bold text-sm block ${daysRemaining <= 0 ? 'text-rose-400' : daysRemaining <= 7 ? 'text-amber-400' : 'text-slate-200'}`}>
              {formatDateIndian(policy.policyExpiryDate)}
            </span>
            <span className="text-[11px] text-slate-400 block">
              {lang === 'hi' ? `शुरू: ${formatDateIndian(policy.policyStartDate)}` : `From: ${formatDateIndian(policy.policyStartDate)}`}
            </span>
          </div>
        </div>

        {/* Insurer & Premium Pill */}
        <div className="flex items-center justify-between text-xs p-2.5 rounded-xl bg-slate-900/70 border border-slate-700/60">
          <div className="flex items-center gap-1.5 truncate max-w-[190px] sm:max-w-[240px]">
            <Shield className="w-3.5 h-3.5 text-blue-400 shrink-0" />
            <div className="truncate">
              <span className="font-medium text-slate-200 block truncate">{policy.insuranceCompany}</span>
              <span className="text-[10px] font-mono text-slate-400 block truncate">#{policy.policyNumber}</span>
            </div>
          </div>

          <div className="text-right shrink-0">
            <span className="font-bold text-emerald-400 text-sm">
              ₹{(policy.premiumAmount || 0).toLocaleString('en-IN')}
            </span>
            {policy.previousNCB !== undefined && (
              <span className="text-[10px] text-slate-400 block">NCB: {policy.previousNCB}%</span>
            )}
          </div>
        </div>

        {/* Last Reminder Sent info */}
        {policy.lastReminderSentAt && (
          <div className="text-[11px] text-emerald-400/90 flex items-center justify-between bg-emerald-950/20 px-2.5 py-1 rounded-lg border border-emerald-500/20">
            <span className="flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              {lang === 'hi' ? 'रिमाइंडर भेजा गया' : 'Reminder Sent'}
            </span>
            <span className="text-slate-400 text-[10px]">
              {new Date(policy.lastReminderSentAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}
            </span>
          </div>
        )}

        {/* Quick Notes if present */}
        {policy.notes && (
          <p className="text-[11px] text-slate-400 bg-slate-900/40 p-2 rounded-lg italic line-clamp-1">
            "{policy.notes}"
          </p>
        )}
      </div>

      {/* Action Buttons: WhatsApp, Call, Renew */}
      <div className="p-3 bg-slate-900/80 border-t border-slate-700/60 flex items-center gap-2">
        {/* WhatsApp Reminder (1-Click) */}
        <button
          onClick={handleWhatsAppClick}
          className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/25 transition active:scale-95"
          title={lang === 'hi' ? 'व्हाट्सएप पर रिमाइंडर भेजें' : 'Send WhatsApp Reminder'}
        >
          <MessageCircle className="w-4 h-4 fill-white text-emerald-600" />
          <span>{lang === 'hi' ? 'व्हाट्सएप अलर्ट' : 'WhatsApp'}</span>
        </button>

        {/* Direct Call */}
        <a
          href={getCallUrl(policy.customerPhone)}
          className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-blue-400 hover:text-white border border-slate-700 transition"
          title={lang === 'hi' ? 'कॉल करें' : 'Call Customer'}
        >
          <Phone className="w-4 h-4" />
        </a>

        {/* Renew Action */}
        <button
          onClick={() => onRenew(policy)}
          className="py-2 px-3 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 hover:text-white border border-blue-500/40 text-xs font-semibold flex items-center gap-1 transition"
          title={lang === 'hi' ? 'पॉलिसी रिन्यूअल' : 'Renew Policy'}
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>{lang === 'hi' ? 'रिन्यू' : 'Renew'}</span>
        </button>

        {/* Copy button */}
        <button
          onClick={handleCopyMessage}
          className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-700 transition"
          title={copied ? 'Copied!' : 'Copy SMS / Message'}
        >
          {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
        </button>

        {/* History Toggle if renewal history exists */}
        {policy.renewalHistory && policy.renewalHistory.length > 0 && (
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 border border-slate-700 transition"
            title="View Past Renewals"
          >
            {showHistory ? <ChevronUp className="w-4 h-4" /> : <History className="w-4 h-4" />}
          </button>
        )}
      </div>

      {/* Expansion for Past Renewal History */}
      {showHistory && policy.renewalHistory && policy.renewalHistory.length > 0 && (
        <div className="p-3 bg-slate-950/70 border-t border-slate-800 text-xs space-y-2">
          <div className="font-semibold text-slate-300 flex items-center gap-1">
            <History className="w-3.5 h-3.5 text-amber-400" />
            <span>{lang === 'hi' ? 'पिछला रिन्यूअल इतिहास:' : 'Renewal History:'}</span>
          </div>
          {policy.renewalHistory.map((h, i) => (
            <div key={h.id || i} className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex justify-between text-[11px]">
              <div>
                <span className="text-slate-400">{lang === 'hi' ? 'पॉलिसी:' : 'Policy:'} #{h.previousPolicyNumber}</span>
                <span className="text-slate-500 block">{h.insuranceCompany}</span>
              </div>
              <div className="text-right">
                <span className="text-emerald-400 font-medium">₹{h.premiumAmount}</span>
                <span className="text-slate-500 block">{formatDateIndian(h.renewedDate)}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

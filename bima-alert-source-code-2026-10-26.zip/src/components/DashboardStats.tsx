import React from 'react';
import { 
  AlertOctagon, 
  Clock, 
  Calendar, 
  ShieldCheck, 
  IndianRupee, 
  BellRing,
  Send,
  ArrowRight
} from 'lucide-react';
import { Policy } from '../types/policy';
import { getDaysRemaining } from '../utils/reminderUtils';

interface Props {
  policies: Policy[];
  lang: 'hi' | 'en';
  activeFilter: string;
  onSelectFilter: (filter: string) => void;
  onNavigateToDaily: () => void;
}

export const DashboardStats: React.FC<Props> = ({
  policies,
  lang,
  activeFilter,
  onSelectFilter,
  onNavigateToDaily,
}) => {
  let expiredCount = 0;
  let criticalCount = 0;
  let upcomingCount = 0;
  let safeCount = 0;
  let totalPremium = 0;

  policies.forEach(p => {
    const days = getDaysRemaining(p.policyExpiryDate);
    totalPremium += Number(p.premiumAmount) || 0;

    if (days < 0) {
      expiredCount++;
    } else if (days <= 7) {
      criticalCount++;
    } else if (days <= 30) {
      upcomingCount++;
    } else {
      safeCount++;
    }
  });

  const urgentTotal = expiredCount + criticalCount;

  return (
    <div className="space-y-4">
      {/* Urgent Warning Banner if any policies are expiring soon or already expired */}
      {urgentTotal > 0 && (
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-rose-950/70 via-red-900/50 to-amber-950/60 border border-rose-500/40 p-4 sm:p-5 shadow-lg">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/40 shrink-0">
                <BellRing className="w-6 h-6 animate-pulse text-rose-400" />
              </div>
              <div>
                <h4 className="font-bold text-white text-sm sm:text-base flex items-center gap-2">
                  <span>
                    {lang === 'hi' 
                      ? `तत्काल ध्यान दें: ${urgentTotal} गाड़ियों की पॉलिसी एक्सपायरी अलर्ट!` 
                      : `Urgent Attention: ${urgentTotal} Vehicle Policies Due/Expired!`}
                  </span>
                </h4>
                <p className="text-xs text-rose-200/80 mt-0.5 leading-relaxed">
                  {lang === 'hi'
                    ? `${expiredCount} पॉलिसी समाप्त हो चुकी हैं एवं ${criticalCount} अगले 7 दिनों में समाप्त होने वाली हैं। तुरंत ग्राहकों को व्हाट्सएप रिमाइंडर भेजें।`
                    : `${expiredCount} policies expired and ${criticalCount} expiring within 7 days. Send WhatsApp renewal reminders.`}
                </p>
              </div>
            </div>

            <button
              onClick={onNavigateToDaily}
              className="w-full sm:w-auto px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-md shadow-rose-600/30 transition active:scale-95 shrink-0"
            >
              <Send className="w-4 h-4" />
              <span>{lang === 'hi' ? 'आज के रिमाइंडर देखें' : 'View Daily Reminders'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Grid of Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-2.5 sm:gap-3.5">
        {/* Expired Card */}
        <button
          onClick={() => onSelectFilter(activeFilter === 'expired' ? 'all' : 'expired')}
          className={`p-3.5 rounded-2xl border text-left transition relative overflow-hidden group ${
            activeFilter === 'expired'
              ? 'bg-rose-950/50 border-rose-500 ring-2 ring-rose-500/30'
              : 'bg-slate-800/80 border-slate-700/80 hover:border-rose-500/50 hover:bg-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-rose-300">
              {lang === 'hi' ? 'एक्सपायर हो चुकी' : 'Expired'}
            </span>
            <AlertOctagon className="w-4 h-4 text-rose-400 group-hover:scale-110 transition" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-white">{expiredCount}</span>
            <span className="text-[11px] text-rose-300/80">{lang === 'hi' ? 'पॉलिसी' : 'cars'}</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 truncate">
            {lang === 'hi' ? 'चालान का खतरा' : 'Traffic penalty risk'}
          </div>
        </button>

        {/* Expiring Soon (0 - 7 Days) */}
        <button
          onClick={() => onSelectFilter(activeFilter === 'critical' ? 'all' : 'critical')}
          className={`p-3.5 rounded-2xl border text-left transition relative overflow-hidden group ${
            activeFilter === 'critical'
              ? 'bg-amber-950/50 border-amber-500 ring-2 ring-amber-500/30'
              : 'bg-slate-800/80 border-slate-700/80 hover:border-amber-500/50 hover:bg-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-amber-300">
              {lang === 'hi' ? '≤ 7 दिन में समाप्त' : 'Due in ≤ 7 Days'}
            </span>
            <Clock className="w-4 h-4 text-amber-400 group-hover:scale-110 transition" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-white">{criticalCount}</span>
            <span className="text-[11px] text-amber-300/80">{lang === 'hi' ? 'अति आवश्यक' : 'urgent'}</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 truncate">
            {lang === 'hi' ? 'तुरंत रिन्यूअल कराएं' : 'Needs urgent call'}
          </div>
        </button>

        {/* Expiring in 8 - 30 Days */}
        <button
          onClick={() => onSelectFilter(activeFilter === 'upcoming' ? 'all' : 'upcoming')}
          className={`p-3.5 rounded-2xl border text-left transition relative overflow-hidden group ${
            activeFilter === 'upcoming'
              ? 'bg-sky-950/50 border-sky-500 ring-2 ring-sky-500/30'
              : 'bg-slate-800/80 border-slate-700/80 hover:border-sky-500/50 hover:bg-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-sky-300">
              {lang === 'hi' ? '8-30 दिन शेष' : 'Due in 8-30 Days'}
            </span>
            <Calendar className="w-4 h-4 text-sky-400 group-hover:scale-110 transition" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-white">{upcomingCount}</span>
            <span className="text-[11px] text-sky-300/80">{lang === 'hi' ? 'इस माह' : 'this month'}</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 truncate">
            {lang === 'hi' ? 'अग्रिम सूचना भेजें' : 'Advance follow-up'}
          </div>
        </button>

        {/* Active & Safe Policies */}
        <button
          onClick={() => onSelectFilter(activeFilter === 'safe' ? 'all' : 'safe')}
          className={`p-3.5 rounded-2xl border text-left transition relative overflow-hidden group ${
            activeFilter === 'safe'
              ? 'bg-emerald-950/50 border-emerald-500 ring-2 ring-emerald-500/30'
              : 'bg-slate-800/80 border-slate-700/80 hover:border-emerald-500/50 hover:bg-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-emerald-300">
              {lang === 'hi' ? 'सक्रिय (>30 दिन)' : 'Active (>30d)'}
            </span>
            <ShieldCheck className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-2xl sm:text-3xl font-extrabold text-white">{safeCount}</span>
            <span className="text-[11px] text-emerald-300/80">{lang === 'hi' ? 'सुरक्षित' : 'safe'}</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 truncate">
            {lang === 'hi' ? 'पूर्णतः वैध बीमा' : 'No action needed'}
          </div>
        </button>

        {/* Total Portfolio Value / Count */}
        <div className="col-span-2 lg:col-span-1 p-3.5 rounded-2xl bg-gradient-to-br from-slate-800 to-indigo-950/50 border border-indigo-500/30 text-left">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-indigo-300">
              {lang === 'hi' ? 'कुल प्रीमियम' : 'Total Premium'}
            </span>
            <IndianRupee className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-xl sm:text-2xl font-extrabold text-white">
              ₹{totalPremium.toLocaleString('en-IN')}
            </span>
          </div>
          <div className="text-[11px] text-indigo-200/70 mt-1 truncate">
            {policies.length} {lang === 'hi' ? 'कुल वाहन सेव हैं' : 'total vehicles'}
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { RefreshCw, X, Check, Calendar, IndianRupee, ShieldCheck } from 'lucide-react';
import { Policy } from '../types/policy';
import { formatDateIndian } from '../utils/reminderUtils';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  policy: Policy | null;
  onConfirmRenewal: (id: string, newPolicyNumber: string, newPremium: number, newInsurer?: string) => void;
  lang: 'hi' | 'en';
}

export const RenewModal: React.FC<Props> = ({
  isOpen,
  onClose,
  policy,
  onConfirmRenewal,
  lang,
}) => {
  if (!isOpen || !policy) return null;

  // Calculate new projected expiry
  const oldExpiry = new Date(policy.policyExpiryDate);
  const nextExpiry = new Date(oldExpiry);
  nextExpiry.setFullYear(nextExpiry.getFullYear() + 1);
  const nextExpiryStr = nextExpiry.toISOString().split('T')[0];

  const [newPolicyNumber, setNewPolicyNumber] = useState(policy.policyNumber);
  const [newPremium, setNewPremium] = useState<number>(policy.premiumAmount);
  const [newInsurer, setNewInsurer] = useState<string>(policy.insuranceCompany);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onConfirmRenewal(policy.id, newPolicyNumber.trim(), Number(newPremium) || policy.premiumAmount, newInsurer.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5 pb-4 border-b border-slate-800">
          <div className="p-3 rounded-xl bg-emerald-600/20 text-emerald-400 border border-emerald-500/30">
            <RefreshCw className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">
              {lang === 'hi' ? 'पॉलिसी रिन्यूअल (Renewal)' : 'Renew Policy'}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {policy.customerName} • {policy.vehicleNumber}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-2 text-xs">
            <div className="flex justify-between text-slate-400">
              <span>{lang === 'hi' ? 'पिछली एक्सपायरी:' : 'Previous Expiry:'}</span>
              <span className="font-semibold text-rose-300">{formatDateIndian(policy.policyExpiryDate)}</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>{lang === 'hi' ? 'नई एक्सपायरी तिथि (+1 वर्ष):' : 'New Expiry (+1 Year):'}</span>
              <span className="font-bold text-emerald-400 text-sm">{formatDateIndian(nextExpiryStr)}</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              {lang === 'hi' ? 'नया पॉलिसी नंबर' : 'New Policy Number'}
            </label>
            <input
              type="text"
              required
              value={newPolicyNumber}
              onChange={(e) => setNewPolicyNumber(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 focus:border-emerald-500 text-white font-mono text-sm outline-hidden"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {lang === 'hi' ? 'नया प्रीमियम राशि (₹)' : 'New Premium (₹)'}
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-slate-500 text-sm">₹</span>
                <input
                  type="number"
                  required
                  value={newPremium}
                  onChange={(e) => setNewPremium(Number(e.target.value))}
                  className="w-full pl-8 pr-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 focus:border-emerald-500 text-white text-sm outline-hidden"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {lang === 'hi' ? 'बीमा कंपनी' : 'Insurance Company'}
              </label>
              <input
                type="text"
                required
                value={newInsurer}
                onChange={(e) => setNewInsurer(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 focus:border-emerald-500 text-white text-sm outline-hidden"
              />
            </div>
          </div>

          <div className="p-3 rounded-xl bg-blue-950/30 border border-blue-500/20 text-xs text-blue-300 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 shrink-0 text-blue-400" />
            <span>
              {lang === 'hi' 
                ? 'रिन्यू करने पर पिछला पॉलिसी रिकॉर्ड इतिहास में सुरक्षित रहेगा।' 
                : 'Old policy record will be safely saved in customer renewal history.'}
            </span>
          </div>

          <div className="flex justify-end gap-3 pt-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-medium transition"
            >
              {lang === 'hi' ? 'रद्द करें' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold shadow-lg shadow-emerald-600/30 transition flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>{lang === 'hi' ? 'रिन्यूअल कन्फर्म करें' : 'Confirm Renewal'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

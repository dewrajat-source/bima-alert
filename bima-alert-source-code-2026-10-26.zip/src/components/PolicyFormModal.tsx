import React, { useState, useEffect } from 'react';
import { 
  X, 
  Car, 
  Bike, 
  Truck, 
  Calendar, 
  IndianRupee, 
  User, 
  Phone, 
  Building2, 
  Shield, 
  Sparkles,
  Check,
  AlertCircle
} from 'lucide-react';
import { Policy, VehicleType, PolicyType } from '../types/policy';
import { formatVehicleNumber } from '../utils/reminderUtils';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSave: (policyData: Omit<Policy, 'id' | 'createdAt' | 'updatedAt'>) => void;
  policyToEdit?: Policy | null;
  lang: 'hi' | 'en';
}

const TOP_INSURERS = [
  'TATA AIG General Insurance',
  'HDFC ERGO General Insurance',
  'ICICI Lombard General Insurance',
  'The New India Assurance Co.',
  'Bajaj Allianz General Insurance',
  'Go Digit General Insurance',
  'SBI General Insurance',
  'United India Insurance Co.',
  'The Oriental Insurance Co.',
  'National Insurance Co.',
  'Reliance General Insurance',
  'Kotak Mahindra General Insurance',
  'Cholamandalam MS General Insurance',
  'Iffco Tokio General Insurance',
  'Royal Sundaram General Insurance',
  'Acko General Insurance',
];

const VEHICLE_PRESETS = [
  'Maruti Suzuki Swift',
  'Hyundai Creta',
  'Hero Splendor Plus',
  'Honda Activa 6G',
  'Maruti Baleno',
  'Tata Nexon',
  'Mahindra Bolero',
  'Mahindra Scorpio',
  'Tata Ace (Chhota Hathi)',
  'Bajaj Pulsar 150',
  'Royal Enfield Classic 350',
  'Maruti WagonR',
  'Toyota Innova Crysta',
];

export const PolicyFormModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onSave,
  policyToEdit,
  lang,
}) => {
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [alternatePhone, setAlternatePhone] = useState('');
  const [customerCity, setCustomerCity] = useState('');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [vehicleType, setVehicleType] = useState<VehicleType>('four_wheeler');
  const [vehicleMakeModel, setVehicleMakeModel] = useState('');
  const [insuranceCompany, setInsuranceCompany] = useState(TOP_INSURERS[0]);
  const [customInsurer, setCustomInsurer] = useState('');
  const [policyNumber, setPolicyNumber] = useState('');
  const [policyType, setPolicyType] = useState<PolicyType>('comprehensive');
  const [premiumAmount, setPremiumAmount] = useState<number | ''>('');
  const [policyStartDate, setPolicyStartDate] = useState('');
  const [policyExpiryDate, setPolicyExpiryDate] = useState('');
  const [previousNCB, setPreviousNCB] = useState<number>(20);
  const [isFinanced, setIsFinanced] = useState(false);
  const [financeBank, setFinanceBank] = useState('');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (policyToEdit) {
      setCustomerName(policyToEdit.customerName);
      setCustomerPhone(policyToEdit.customerPhone);
      setAlternatePhone(policyToEdit.alternatePhone || '');
      setCustomerCity(policyToEdit.customerCity || '');
      setVehicleNumber(policyToEdit.vehicleNumber);
      setVehicleType(policyToEdit.vehicleType);
      setVehicleMakeModel(policyToEdit.vehicleMakeModel || '');
      if (TOP_INSURERS.includes(policyToEdit.insuranceCompany)) {
        setInsuranceCompany(policyToEdit.insuranceCompany);
        setCustomInsurer('');
      } else {
        setInsuranceCompany('Other');
        setCustomInsurer(policyToEdit.insuranceCompany);
      }
      setPolicyNumber(policyToEdit.policyNumber);
      setPolicyType(policyToEdit.policyType);
      setPremiumAmount(policyToEdit.premiumAmount);
      setPolicyStartDate(policyToEdit.policyStartDate);
      setPolicyExpiryDate(policyToEdit.policyExpiryDate);
      setPreviousNCB(policyToEdit.previousNCB ?? 20);
      setIsFinanced(policyToEdit.isFinanced ?? false);
      setFinanceBank(policyToEdit.financeBank || '');
      setNotes(policyToEdit.notes || '');
    } else {
      // Default dates: Today as start, +1 year -1 day as expiry
      const today = new Date();
      const startStr = today.toISOString().split('T')[0];
      const expiry = new Date(today);
      expiry.setFullYear(expiry.getFullYear() + 1);
      expiry.setDate(expiry.getDate() - 1);
      const expiryStr = expiry.toISOString().split('T')[0];

      setCustomerName('');
      setCustomerPhone('');
      setAlternatePhone('');
      setCustomerCity('');
      setVehicleNumber('');
      setVehicleType('four_wheeler');
      setVehicleMakeModel('');
      setInsuranceCompany(TOP_INSURERS[0]);
      setCustomInsurer('');
      setPolicyNumber('');
      setPolicyType('comprehensive');
      setPremiumAmount('');
      setPolicyStartDate(startStr);
      setPolicyExpiryDate(expiryStr);
      setPreviousNCB(20);
      setIsFinanced(false);
      setFinanceBank('');
      setNotes('');
    }
    setErrors({});
  }, [policyToEdit, isOpen]);

  if (!isOpen) return null;

  // Auto calculate expiry 1 year from start date
  const handleStartDateChange = (val: string) => {
    setPolicyStartDate(val);
    if (val) {
      const d = new Date(val);
      d.setFullYear(d.getFullYear() + 1);
      d.setDate(d.getDate() - 1);
      setPolicyExpiryDate(d.toISOString().split('T')[0]);
    }
  };

  const validate = () => {
    const err: Record<string, string> = {};
    if (!customerName.trim()) {
      err.customerName = lang === 'hi' ? 'ग्राहक का नाम अनिवार्य है।' : 'Customer name is required.';
    }
    if (!customerPhone.trim() || customerPhone.replace(/\D/g, '').length < 10) {
      err.customerPhone = lang === 'hi' ? 'वैध 10 अंकों का मोबाइल नंबर दर्ज करें।' : 'Enter valid 10-digit mobile number.';
    }
    if (!vehicleNumber.trim()) {
      err.vehicleNumber = lang === 'hi' ? 'गाड़ी का नंबर आवश्यक है।' : 'Vehicle number is required.';
    }
    if (!policyExpiryDate) {
      err.policyExpiryDate = lang === 'hi' ? 'एक्सपायरी डेट दर्ज करें।' : 'Expiry date is required.';
    }
    setErrors(err);
    return Object.keys(err).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const finalInsurer = insuranceCompany === 'Other' ? (customInsurer.trim() || 'Other Insurer') : insuranceCompany;

    onSave({
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      alternatePhone: alternatePhone.trim() || undefined,
      customerCity: customerCity.trim() || undefined,
      vehicleNumber: formatVehicleNumber(vehicleNumber),
      vehicleType,
      vehicleMakeModel: vehicleMakeModel.trim(),
      insuranceCompany: finalInsurer,
      policyNumber: policyNumber.trim() || `POL-${Date.now().toString().slice(-6)}`,
      policyType,
      premiumAmount: Number(premiumAmount) || 0,
      policyStartDate: policyStartDate || new Date().toISOString().split('T')[0],
      policyExpiryDate,
      previousNCB,
      reminderDaysBefore: [30, 15, 7, 3, 1, 0],
      isFinanced,
      financeBank: isFinanced ? financeBank.trim() : undefined,
      notes: notes.trim() || undefined,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl p-5 sm:p-7 text-slate-100 my-6">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-800">
          <div className="p-3 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 text-white shadow-md shadow-blue-500/20">
            <Car className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">
              {policyToEdit 
                ? (lang === 'hi' ? 'पॉलिसी विवरण अपडेट करें' : 'Edit Motor Policy Details')
                : (lang === 'hi' ? 'नया ग्राहक एवं मोटर पॉलिसी जोड़ें' : 'Save New Customer & Motor Policy')}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {lang === 'hi' 
                ? 'गाड़ी नंबर और समाप्ति तिथि सेव करें, ताकि सटीक व्हाट्सएप व कॉल रिमाइंडर मिल सके।' 
                : 'Save details to receive automatic expiry alerts and WhatsApp reminders.'}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Section 1: Customer Details */}
          <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-3.5">
            <div className="text-xs font-semibold text-blue-400 uppercase tracking-wider flex items-center gap-1.5">
              <User className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? '1. ग्राहक विवरण (Customer Info)' : '1. Customer Information'}</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {lang === 'hi' ? 'ग्राहक का नाम *' : 'Customer Name *'}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    placeholder={lang === 'hi' ? 'उदा. राहुल शर्मा' : 'e.g. Rahul Sharma'}
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-white text-sm placeholder:text-slate-500 outline-hidden"
                  />
                </div>
                {errors.customerName && (
                  <p className="text-rose-400 text-xs mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.customerName}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {lang === 'hi' ? 'मोबाइल नंबर (WhatsApp) *' : 'Mobile Number (WhatsApp) *'}
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-slate-500 text-sm font-medium">+91</span>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    placeholder="9829012345"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value.replace(/\D/g, ''))}
                    className="w-full pl-12 pr-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-white text-sm placeholder:text-slate-500 outline-hidden tracking-wider"
                  />
                </div>
                {errors.customerPhone && (
                  <p className="text-rose-400 text-xs mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.customerPhone}
                  </p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  {lang === 'hi' ? 'शहर / पता (वैकल्पिक)' : 'City / Area (Optional)'}
                </label>
                <input
                  type="text"
                  placeholder={lang === 'hi' ? 'उदा. जयपुर' : 'e.g. Jaipur'}
                  value={customerCity}
                  onChange={(e) => setCustomerCity(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:border-blue-500 text-white text-sm placeholder:text-slate-500 outline-hidden"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  {lang === 'hi' ? 'दूसरा फोन नंबर (वैकल्पिक)' : 'Alternate Phone (Optional)'}
                </label>
                <input
                  type="tel"
                  placeholder="9414000000"
                  value={alternatePhone}
                  onChange={(e) => setAlternatePhone(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:border-blue-500 text-white text-sm placeholder:text-slate-500 outline-hidden"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Vehicle Information */}
          <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-3.5">
            <div className="text-xs font-semibold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
              <Car className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? '2. वाहन का विवरण (Vehicle Info)' : '2. Vehicle Information'}</span>
            </div>

            {/* Vehicle Type Selector */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                {lang === 'hi' ? 'वाहन का प्रकार' : 'Vehicle Type'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'four_wheeler', label: lang === 'hi' ? 'कार / फोर-व्हीलर' : 'Car / 4-Wheeler', icon: Car },
                  { id: 'two_wheeler', label: lang === 'hi' ? 'बाइक / स्कूटर' : 'Two Wheeler', icon: Bike },
                  { id: 'commercial', label: lang === 'hi' ? 'कमर्शियल / छोटा हाथी' : 'Commercial Goods', icon: Truck },
                  { id: 'taxi', label: lang === 'hi' ? 'टैक्सी / ऑटो' : 'Taxi / Passenger', icon: Car },
                ].map(item => {
                  const Icon = item.icon;
                  const isSelected = vehicleType === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setVehicleType(item.id as VehicleType)}
                      className={`p-2 rounded-xl border text-xs font-medium flex items-center justify-center gap-1.5 transition ${
                        isSelected 
                          ? 'bg-emerald-600/20 border-emerald-500 text-emerald-300 ring-1 ring-emerald-500/50' 
                          : 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span className="truncate">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {/* Vehicle Number */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {lang === 'hi' ? 'गाड़ी का नंबर (Registration No.) *' : 'Vehicle Number *'}
                </label>
                <input
                  type="text"
                  required
                  placeholder="RJ 14 CA 1234"
                  value={vehicleNumber}
                  onChange={(e) => setVehicleNumber(e.target.value.toUpperCase())}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-white font-mono font-bold text-sm tracking-wider uppercase outline-hidden"
                />
                {errors.vehicleNumber && (
                  <p className="text-rose-400 text-xs mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.vehicleNumber}
                  </p>
                )}
              </div>

              {/* Make & Model */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {lang === 'hi' ? 'मेक व मॉडल (Make & Model)' : 'Make & Model'}
                </label>
                <input
                  type="text"
                  placeholder={lang === 'hi' ? 'उदा. Maruti Swift VXi / Splendor' : 'e.g. Maruti Swift VXi'}
                  value={vehicleMakeModel}
                  onChange={(e) => setVehicleMakeModel(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 focus:border-emerald-500 text-white text-sm placeholder:text-slate-500 outline-hidden"
                />
              </div>
            </div>

            {/* Quick Model Chips */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              <span className="text-[11px] text-slate-400 self-center">
                {lang === 'hi' ? 'जल्दी चुनें:' : 'Quick pick:'}
              </span>
              {VEHICLE_PRESETS.slice(0, 6).map(preset => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setVehicleMakeModel(preset)}
                  className="px-2 py-0.5 text-[11px] rounded-lg bg-slate-900 hover:bg-slate-700 text-slate-300 border border-slate-700/80 transition"
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>

          {/* Section 3: Policy & Expiry Information */}
          <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-3.5">
            <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? '3. पॉलिसी एवं एक्सपायरी विवरण (Policy & Expiry)' : '3. Policy & Expiry'}</span>
            </div>

            {/* Insurer Dropdown */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {lang === 'hi' ? 'बीमा कंपनी (Insurance Company)' : 'Insurance Company'}
                </label>
                <select
                  value={insuranceCompany}
                  onChange={(e) => setInsuranceCompany(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 focus:border-amber-500 text-white text-sm outline-hidden cursor-pointer"
                >
                  {TOP_INSURERS.map(ins => (
                    <option key={ins} value={ins}>{ins}</option>
                  ))}
                  <option value="Other">{lang === 'hi' ? '+ अन्य कंपनी (Custom)' : '+ Other Insurer'}</option>
                </select>
                {insuranceCompany === 'Other' && (
                  <input
                    type="text"
                    placeholder="Enter company name"
                    value={customInsurer}
                    onChange={(e) => setCustomInsurer(e.target.value)}
                    className="mt-2 w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm outline-hidden"
                  />
                )}
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {lang === 'hi' ? 'पॉलिसी नंबर' : 'Policy Number'}
                </label>
                <input
                  type="text"
                  placeholder="OG-25-1102-1801..."
                  value={policyNumber}
                  onChange={(e) => setPolicyNumber(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 focus:border-amber-500 text-white text-sm font-mono placeholder:text-slate-500 outline-hidden"
                />
              </div>
            </div>

            {/* Start and Expiry Dates */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {lang === 'hi' ? 'पॉलिसी शुरू तिथि (Start Date)' : 'Policy Start Date'}
                </label>
                <input
                  type="date"
                  value={policyStartDate}
                  onChange={(e) => handleStartDateChange(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 focus:border-amber-500 text-white text-sm outline-hidden cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-amber-300 mb-1 flex items-center justify-between">
                  <span>{lang === 'hi' ? 'समाप्ति तिथि (Expiry Date) *' : 'Policy Expiry Date *'}</span>
                  <span className="text-[10px] text-amber-400 font-normal">
                    {lang === 'hi' ? '(इसी पर अलर्ट बजेगा)' : '(Drives alert)'}
                  </span>
                </label>
                <input
                  type="date"
                  required
                  value={policyExpiryDate}
                  onChange={(e) => setPolicyExpiryDate(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-amber-950/30 border border-amber-500/80 focus:border-amber-400 text-amber-200 font-semibold text-sm outline-hidden cursor-pointer shadow-sm"
                />
                {errors.policyExpiryDate && (
                  <p className="text-rose-400 text-xs mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.policyExpiryDate}
                  </p>
                )}
              </div>
            </div>

            {/* Premium, Policy Type & NCB */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {lang === 'hi' ? 'प्रीमियम राशि (₹)' : 'Premium (₹)'}
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-slate-500 text-sm">₹</span>
                  <input
                    type="number"
                    placeholder="5400"
                    value={premiumAmount}
                    onChange={(e) => setPremiumAmount(e.target.value ? Number(e.target.value) : '')}
                    className="w-full pl-8 pr-3 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:border-amber-500 text-white text-sm outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {lang === 'hi' ? 'पॉलिसी प्रकार' : 'Policy Type'}
                </label>
                <select
                  value={policyType}
                  onChange={(e) => setPolicyType(e.target.value as PolicyType)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:border-amber-500 text-white text-sm outline-hidden"
                >
                  <option value="comprehensive">{lang === 'hi' ? 'कॉम्प्रिहेंसिव (फुल पैकेज)' : 'Comprehensive (Full)'}</option>
                  <option value="third_party">{lang === 'hi' ? 'थर्ड पार्टी (TP Only)' : 'Third Party (TP Only)'}</option>
                  <option value="standalone_od">{lang === 'hi' ? 'ओन डैमेज (OD Only)' : 'Standalone OD'}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  {lang === 'hi' ? 'NCB (नो क्लेम बोनस %)' : 'NCB Bonus %'}
                </label>
                <select
                  value={previousNCB}
                  onChange={(e) => setPreviousNCB(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:border-amber-500 text-white text-sm outline-hidden"
                >
                  <option value={0}>0%</option>
                  <option value={20}>20%</option>
                  <option value={25}>25%</option>
                  <option value={35}>35%</option>
                  <option value={45}>45%</option>
                  <option value={50}>50%</option>
                </select>
              </div>
            </div>

            {/* Bank Finance & Notes */}
            <div className="pt-1">
              <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isFinanced}
                  onChange={(e) => setIsFinanced(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-900 text-blue-600 focus:ring-0"
                />
                <span>{lang === 'hi' ? 'वाहन बैंक लोन पर है (Hypothecated)?' : 'Vehicle is Financed (Hypothecated)?'}</span>
              </label>

              {isFinanced && (
                <input
                  type="text"
                  placeholder={lang === 'hi' ? 'बैंक का नाम (उदा. SBI Car Loan, HDFC Bank)' : 'Bank Name'}
                  value={financeBank}
                  onChange={(e) => setFinanceBank(e.target.value)}
                  className="mt-2 w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm outline-hidden"
                />
              )}
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">
                {lang === 'hi' ? 'नोट्स / रिमार्क्स (वैकल्पिक)' : 'Notes / Remarks (Optional)'}
              </label>
              <textarea
                rows={2}
                placeholder={lang === 'hi' ? 'उदा. ग्राहक ने कॉल करने का समय शाम 6 बजे बोला है' : 'Notes for future reference'}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:border-amber-500 text-white text-sm placeholder:text-slate-500 outline-hidden resize-none"
              />
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-end gap-3 pt-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-medium transition"
            >
              {lang === 'hi' ? 'रद्द करें' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-sm font-semibold shadow-lg shadow-blue-500/30 transition active:scale-95 flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>{policyToEdit ? (lang === 'hi' ? 'अपडेट सुरक्षित करें' : 'Save Changes') : (lang === 'hi' ? 'पॉलिसी सेव करें' : 'Save Policy')}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  X, 
  Smartphone, 
  Monitor, 
  Globe,
  CheckCircle2, 
  ArrowRight, 
  ExternalLink,
  Youtube,
  MousePointer,
  Sparkles,
  Download,
  Github,
  Zap,
  ShieldCheck
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  lang: 'hi' | 'en';
}

export const InstallVideoModal: React.FC<Props> = ({ isOpen, onClose, lang }) => {
  const [device, setDevice] = useState<'mobile' | 'pc' | 'vercel'>('vercel');
  const [currentStep, setCurrentStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  const mobileSteps = [
    {
      title: lang === 'hi' ? 'स्टेप 1: Chrome में लिंक खोलें' : 'Step 1: Open link in Chrome',
      desc: lang === 'hi' ? 'अपने फोन में Google Chrome ब्राउज़र में ऐप का लिंक खोलें।' : 'Open the app link in Google Chrome on your mobile.',
      screen: 'browser',
    },
    {
      title: lang === 'hi' ? 'स्टेप 2: ऊपर 3-डॉट्स (⋮) पर टैप करें' : 'Step 2: Tap the 3 dots (⋮)',
      desc: lang === 'hi' ? 'Chrome में ऊपर दाईं तरफ दिए गए 3-डॉट्स (मेनू) बटन पर क्लिक करें।' : 'Click the 3 vertical dots menu in the top right of Chrome.',
      screen: 'menu',
    },
    {
      title: lang === 'hi' ? 'स्टेप 3: "Install App" चुनें' : 'Step 3: Select "Install App"',
      desc: lang === 'hi' ? 'मेनू में से "Install App" या "होम स्क्रीन पर जोड़ें" पर टैप करें।' : 'Tap "Install app" or "Add to Home screen" from the menu options.',
      screen: 'prompt',
    },
    {
      title: lang === 'hi' ? 'स्टेप 4: ऐप तैयार!' : 'Step 4: App is Installed!',
      desc: lang === 'hi' ? 'ऐप आपके फोन की होम स्क्रीन पर असली APK की तरह इंस्टॉल हो गई है!' : 'App is now on your phone home screen like a native APK!',
      screen: 'homescreen',
    },
  ];

  const pcSteps = [
    {
      title: lang === 'hi' ? 'स्टेप 1: कंप्यूटर में Chrome/Edge खोलें' : 'Step 1: Open Chrome/Edge on PC',
      desc: lang === 'hi' ? 'अपने कंप्यूटर पर लिंक खोलें।' : 'Open the link in your computer browser.',
      screen: 'pc_browser',
    },
    {
      title: lang === 'hi' ? 'स्टेप 2: एड्रेस बार में 🖥️ आइकन देखें' : 'Step 2: Look at Address Bar',
      desc: lang === 'hi' ? 'ऊपर जहां URL लिखा होता है, दाईं तरफ एक 🖥️ या ⬇️ "Install" आइकन दिखेगा।' : 'Notice the 🖥️ or ⬇️ Install icon on the right side of the address bar.',
      screen: 'pc_address_bar',
    },
    {
      title: lang === 'hi' ? 'स्टेप 3: "Install" बटन दबाएं' : 'Step 3: Click "Install"',
      desc: lang === 'hi' ? 'पॉपअप में "Install" पर क्लिक करें।' : 'Click "Install" on the confirmation dialog.',
      screen: 'pc_dialog',
    },
    {
      title: lang === 'hi' ? 'स्टेप 4: डेस्कटॉप पर सॉफ्टवेयर तैयार!' : 'Step 4: Desktop Software Ready!',
      desc: lang === 'hi' ? 'Windows Desktop और Taskbar पर सॉफ्टवेयर का आइकन आ जाएगा और अलग विंडो में खुलेगा!' : 'App icon is now pinned to your Windows Desktop and Taskbar!',
      screen: 'pc_desktop',
    },
  ];

  const vercelSteps = [
    {
      title: lang === 'hi' ? 'स्टेप 1: GitHub पर कोड रिपॉजिटरी बनाएं' : 'Step 1: Push Code to GitHub',
      desc: lang === 'hi' ? 'GitHub.com पर फ्री अकाउंट बनाकर "New Repository" में कोड अपलोड करें।' : 'Create a free GitHub repository and push your project code.',
      screen: 'github_upload',
    },
    {
      title: lang === 'hi' ? 'स्टेप 2: Vercel.com पर GitHub से लॉगिन करें' : 'Step 2: Login to Vercel with GitHub',
      desc: lang === 'hi' ? 'Vercel.com पर जाएं और "Sign Up with GitHub" पर क्लिक करें (100% Free)।' : 'Open Vercel.com and sign up with GitHub (free lifetime tier).',
      screen: 'vercel_connect',
    },
    {
      title: lang === 'hi' ? 'स्टेप 3: "Import" करके "Deploy" दबाएं' : 'Step 3: Select Repo and Tap Deploy',
      desc: lang === 'hi' ? 'अपने प्रोजेक्ट के आगे "Import" और फिर "Deploy" दबाएं। यह 30 सेकंड में ऑटोमैटिक डिप्लॉय हो जाएगा।' : 'Click Import and Deploy. Vercel automatically builds Vite in 30s.',
      screen: 'vercel_building',
    },
    {
      title: lang === 'hi' ? 'स्टेप 4: 24x7 परमानेंट लिंक तैयार!' : 'Step 4: Permanent Lifetime Link Ready!',
      desc: lang === 'hi' ? 'आपको https://bima-alert.vercel.app लिंक मिल गया जो कभी बंद नहीं होगा और PWABuilder में भी चलेगा!' : 'You get a live permanent link that never expires and works with PWABuilder!',
      screen: 'vercel_live',
    },
  ];

  const steps = device === 'mobile' ? mobileSteps : device === 'pc' ? pcSteps : vercelSteps;

  // Auto-play animation timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isOpen && isPlaying) {
      timer = setInterval(() => {
        setCurrentStep((prev) => (prev + 1) % steps.length);
      }, 3500);
    }
    return () => clearInterval(timer);
  }, [isOpen, isPlaying, steps.length]);

  if (!isOpen) return null;

  const handleDeviceChange = (d: 'mobile' | 'pc' | 'vercel') => {
    setDevice(d);
    setCurrentStep(0);
    setIsPlaying(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl p-5 sm:p-6 text-slate-100 my-6">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-4 pb-3 border-b border-slate-800">
          <div className="p-3 bg-red-600/20 text-red-400 rounded-2xl border border-red-500/30">
            <Youtube className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <span>{lang === 'hi' ? '🎥 वीडियो ट्यूटोरियल: डाउनलोड व परमानेंट होस्टिंग' : '🎥 Video Guide: Install & Permanent Hosting'}</span>
            </h3>
            <p className="text-xs text-slate-400">
              {lang === 'hi' 
                ? 'नीचे स्क्रीन एनीमेशन और यूट्यूब वीडियो देखकर 2 मिनट में सीखें।' 
                : 'Watch animated walkthroughs and YouTube tutorials below.'}
            </p>
          </div>
        </div>

        {/* Tab Switcher: Vercel / GitHub vs Phone vs PC */}
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-800/80 rounded-2xl border border-slate-700 mb-4 text-xs font-semibold">
          <button
            onClick={() => handleDeviceChange('vercel')}
            className={`py-2 px-2.5 rounded-xl flex items-center justify-center gap-1.5 transition text-center ${
              device === 'vercel'
                ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md shadow-blue-600/30 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Globe className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">{lang === 'hi' ? '🌐 GitHub + Vercel' : '🌐 GitHub + Vercel'}</span>
          </button>

          <button
            onClick={() => handleDeviceChange('mobile')}
            className={`py-2 px-2.5 rounded-xl flex items-center justify-center gap-1.5 transition text-center ${
              device === 'mobile'
                ? 'bg-red-600 text-white shadow-md shadow-red-600/30 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">{lang === 'hi' ? '📱 फोन APK' : '📱 Mobile APK'}</span>
          </button>

          <button
            onClick={() => handleDeviceChange('pc')}
            className={`py-2 px-2.5 rounded-xl flex items-center justify-center gap-1.5 transition text-center ${
              device === 'pc'
                ? 'bg-red-600 text-white shadow-md shadow-red-600/30 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Monitor className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">{lang === 'hi' ? '💻 कंप्यूटर PC' : '💻 PC .EXE'}</span>
          </button>
        </div>

        {/* Animated Video Player Simulator Frame */}
        <div className="relative rounded-2xl bg-slate-950 border-2 border-slate-700/80 p-4 sm:p-6 overflow-hidden shadow-2xl min-h-[290px] flex flex-col justify-between">
          {/* Frame 1: Vercel / GitHub Deployment Simulation */}
          {device === 'vercel' ? (
            <div className="relative w-full max-w-lg mx-auto bg-slate-900 border-2 border-slate-700 rounded-2xl p-4 shadow-xl min-h-[240px] flex flex-col justify-between">
              {/* Window Header */}
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-xs">
                <div className="flex items-center gap-2">
                  <Globe className="w-4 h-4 text-blue-400" />
                  <span className="font-bold text-white">Vercel & GitHub Deployment</span>
                </div>
                <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 font-mono text-[10px]">100% Free Lifetime</span>
              </div>

              {/* Vercel Step 0: GitHub Repo */}
              {currentStep === 0 && (
                <div className="text-center py-5 space-y-2.5 animate-fadeIn">
                  <div className="w-12 h-12 rounded-2xl bg-slate-800 border border-slate-700 text-white flex items-center justify-center mx-auto shadow-lg">
                    <Github className="w-7 h-7 text-white" />
                  </div>
                  <div className="text-xs font-bold text-white">GitHub.com: bima-alert-app</div>
                  <p className="text-[11px] text-slate-400">आपकी मोटर पॉलिसी ऐप का कोड GitHub पर तैयार है।</p>
                </div>
              )}

              {/* Vercel Step 1: Connect GitHub */}
              {currentStep === 1 && (
                <div className="text-center py-5 space-y-2.5 animate-fadeIn">
                  <div className="w-12 h-12 rounded-2xl bg-white text-slate-950 flex items-center justify-center mx-auto shadow-xl">
                    ▲
                  </div>
                  <div className="text-xs font-bold text-white">Vercel.com पर "Continue with GitHub"</div>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-[11px] text-slate-200">
                    <MousePointer className="w-3.5 h-3.5 text-blue-400 animate-bounce" />
                    <span>1-क्लिक में आपका GitHub Vercel से कनेक्ट हो जाता है</span>
                  </div>
                </div>
              )}

              {/* Vercel Step 2: Deploy */}
              {currentStep === 2 && (
                <div className="text-center py-5 space-y-2.5 animate-fadeIn">
                  <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto shadow-lg shadow-blue-500/40 animate-pulse">
                    <Zap className="w-6 h-6" />
                  </div>
                  <div className="text-xs font-bold text-white">Building & Deploying...</div>
                  <p className="text-[11px] text-slate-400">Vercel ऑटोमैटिकली Vite कोड को 30 सेकंड में बिल्ड कर रहा है...</p>
                </div>
              )}

              {/* Vercel Step 3: Success URL */}
              {currentStep === 3 && (
                <div className="text-center py-4 space-y-2 animate-fadeIn">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center mx-auto shadow-lg">
                    <CheckCircle2 className="w-7 h-7 text-white" />
                  </div>
                  <div className="text-xs font-bold text-emerald-400">लाइफटाइम परमानेंट लिंक एक्टिव!</div>
                  <div className="p-2 rounded-xl bg-slate-950 border border-emerald-500/40 text-emerald-300 font-mono text-xs select-all">
                    https://bima-alert.vercel.app
                  </div>
                  <p className="text-[10px] text-slate-400">यह लिंक कभी एक्सपायर नहीं होगा, और PWABuilder पर भी 100% पास होगा!</p>
                </div>
              )}

              <div className="w-full bg-slate-800 h-1 rounded-full mt-2 overflow-hidden">
                <div 
                  className="bg-blue-500 h-full transition-all duration-500" 
                  style={{ width: `${((currentStep + 1) / vercelSteps.length) * 100}%` }}
                />
              </div>
            </div>
          ) : device === 'mobile' ? (
            /* Mobile Device Simulator */
            <div className="relative w-full max-w-sm mx-auto bg-slate-900 border-4 border-slate-700 rounded-3xl p-3 shadow-xl min-h-[240px] flex flex-col justify-between">
              <div className="w-20 h-3 bg-slate-800 rounded-full mx-auto mb-2" />
              <div className="flex-1 rounded-2xl bg-slate-950 border border-slate-800 p-3 relative overflow-hidden flex flex-col justify-between">
                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-800/90 text-[11px] mb-3">
                  <span className="truncate font-mono text-emerald-400 max-w-[140px]">bima-alert.app</span>
                  <div className="relative flex items-center gap-1">
                    <span className="w-4 h-4 rounded-full bg-slate-700 flex items-center justify-center text-[9px] text-white">1</span>
                    <div className={`p-1 rounded-md text-white font-bold transition ${currentStep === 1 ? 'bg-red-600 animate-ping' : ''}`}>
                      ⋮
                    </div>
                  </div>
                </div>

                {currentStep === 0 && (
                  <div className="text-center py-4 space-y-1.5 animate-fadeIn">
                    <div className="w-10 h-10 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <div className="text-xs font-bold text-white">BimaAlert - मोटर पॉलिसी ऐप</div>
                    <p className="text-[10px] text-slate-400">लिंक Chrome में खुला हुआ है</p>
                  </div>
                )}

                {currentStep === 1 && (
                  <div className="relative animate-fadeIn">
                    <div className="absolute right-0 top-0 w-44 rounded-xl bg-slate-800 border border-slate-600 shadow-2xl p-1.5 space-y-1 text-[11px] text-left">
                      <div className="p-1 text-slate-400">New tab</div>
                      <div className="p-1 bg-blue-600 text-white rounded-lg font-bold flex items-center justify-between animate-pulse">
                        <span>📲 Install app</span>
                        <MousePointer className="w-3.5 h-3.5" />
                      </div>
                      <div className="p-1 text-slate-400">Settings</div>
                    </div>
                  </div>
                )}

                {currentStep === 2 && (
                  <div className="my-auto p-2.5 rounded-2xl bg-slate-800 border border-emerald-500 shadow-2xl text-center space-y-1.5 animate-fadeIn">
                    <Download className="w-6 h-6 text-emerald-400 mx-auto animate-bounce" />
                    <div className="text-xs font-bold text-white">Install BimaAlert?</div>
                    <div className="flex gap-2 pt-1">
                      <div className="flex-1 py-1 rounded bg-slate-700 text-[10px] text-slate-300">Cancel</div>
                      <div className="flex-1 py-1 rounded bg-emerald-600 text-[10px] text-white font-bold">Install</div>
                    </div>
                  </div>
                )}

                {currentStep === 3 && (
                  <div className="text-center py-4 space-y-1.5 animate-fadeIn">
                    <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                    <div className="text-xs font-bold text-emerald-400">फोन में APK तैयार!</div>
                    <p className="text-[10px] text-slate-300">होम स्क्रीन से बिना इंटरनेट भी चलेगा।</p>
                  </div>
                )}

                <div className="w-16 h-1 bg-slate-700 rounded-full mx-auto mt-2" />
              </div>
            </div>
          ) : (
            /* PC Windows Simulator */
            <div className="relative w-full max-w-lg mx-auto bg-slate-900 border-2 border-slate-700 rounded-2xl p-3 shadow-xl min-h-[240px] flex flex-col justify-between">
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                </div>
                <div className="text-[11px] text-slate-400 font-medium">Google Chrome / Microsoft Edge</div>
                <div className="w-8" />
              </div>

              <div className="p-2 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-between gap-2 text-xs mb-3">
                <span className="font-mono text-emerald-400 text-[11px] truncate">https://bima-alert.app</span>
                <div className={`flex items-center gap-1 px-2 py-0.5 rounded-md font-bold text-[11px] transition ${
                  currentStep === 1 || currentStep === 2 ? 'bg-blue-600 text-white ring-2 ring-blue-400 animate-pulse' : 'bg-slate-700 text-slate-300'
                }`}>
                  <Download className="w-3 h-3" />
                  <span>Install app</span>
                </div>
              </div>

              {currentStep === 0 && (
                <div className="text-center py-4 space-y-1">
                  <div className="text-xs font-bold text-white">BimaAlert Windows App</div>
                  <p className="text-[11px] text-slate-400">Chrome/Edge में खुला हुआ है।</p>
                </div>
              )}

              {currentStep === 1 && (
                <div className="text-center py-4 space-y-1.5">
                  <div className="inline-flex items-center gap-2 p-2 rounded-xl bg-blue-950/60 border border-blue-500/50 text-xs text-blue-300">
                    <MousePointer className="w-4 h-4 text-amber-400 animate-bounce" />
                    <span>एड्रेस बार में <strong>"Install app"</strong> बटन दबाएं</span>
                  </div>
                </div>
              )}

              {currentStep === 2 && (
                <div className="mx-auto w-64 p-3 rounded-xl bg-slate-800 border-2 border-blue-500 shadow-2xl text-center space-y-1.5">
                  <div className="text-xs font-bold text-white">Install BimaAlert?</div>
                  <div className="flex gap-2 pt-1">
                    <button className="flex-1 py-1 rounded bg-slate-700 text-[10px]">Cancel</button>
                    <button className="flex-1 py-1 rounded bg-blue-600 text-[10px] font-bold text-white">Install</button>
                  </div>
                </div>
              )}

              {currentStep === 3 && (
                <div className="text-center py-4 space-y-1">
                  <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                  <div className="text-xs font-bold text-emerald-400">Windows PC पर सॉफ्टवेयर तैयार!</div>
                  <p className="text-[10px] text-slate-300">टास्कबार और डेस्कटॉप पर पिन हो गया है।</p>
                </div>
              )}

              <div className="mt-2 p-1 rounded-lg bg-slate-950 border border-slate-800 flex items-center gap-2 text-[10px]">
                <span className="text-slate-400 font-bold">🪟 Start</span>
                <span className="text-slate-600">|</span>
                <span className="p-1 rounded bg-blue-600 text-white font-bold">🛡️ BimaAlert</span>
              </div>
            </div>
          )}

          {/* Player Controls & Step Navigator */}
          <div className="mt-4 pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-1.5">
              {steps.map((s, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentStep(idx)}
                  className={`h-2 rounded-full transition-all ${
                    idx === currentStep ? 'w-6 bg-red-500' : 'w-2 bg-slate-700 hover:bg-slate-500'
                  }`}
                  title={s.title}
                />
              ))}
            </div>

            <div className="text-left flex-1 min-w-[200px] px-2">
              <span className="text-xs font-bold text-white block">
                {steps[currentStep].title}
              </span>
              <span className="text-[11px] text-slate-400 block truncate">
                {steps[currentStep].desc}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                title={isPlaying ? 'Pause' : 'Play'}
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 text-emerald-400" />}
              </button>
              <button
                onClick={() => { setCurrentStep(0); setIsPlaying(true); }}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                title="Restart Video"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Live YouTube Hindi Video Tutorial Links */}
        <div className="mt-4 p-4 rounded-2xl bg-red-950/30 border border-red-500/30 space-y-3 text-xs">
          <div className="flex items-center gap-2.5 text-slate-200">
            <Youtube className="w-5 h-5 text-red-500 shrink-0" />
            <div>
              <span className="font-bold text-white block">
                {lang === 'hi' ? '📺 YouTube पर हिंदी में लाइव वीडियो देखें:' : '📺 Watch live Hindi video tutorials on YouTube:'}
              </span>
              <span className="text-slate-400 text-[11px] block">
                {lang === 'hi' ? 'नीचे दिए गए बटन पर क्लिक करके सीधे यूट्यूब पर 2 मिनट का वीडियो ट्यूटोरियल देखें:' : 'Click below to watch 2-minute Hindi tutorials on YouTube:'}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <a
              href="https://www.youtube.com/results?search_query=how+to+deploy+vite+react+app+on+vercel+github+hindi"
              target="_blank"
              rel="noreferrer"
              className="px-3.5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-md shadow-red-600/30 transition active:scale-95"
            >
              <Youtube className="w-4 h-4" />
              <span>{lang === 'hi' ? '▶️ GitHub से Vercel वीडियो (हिंदी)' : '▶️ GitHub to Vercel (Hindi)'}</span>
              <ExternalLink className="w-3.5 h-3.5 ml-auto" />
            </a>

            <a
              href="https://www.youtube.com/results?search_query=how+to+deploy+react+app+on+netlify+github+hindi"
              target="_blank"
              rel="noreferrer"
              className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-2 border border-slate-700 transition active:scale-95"
            >
              <Globe className="w-4 h-4 text-teal-400" />
              <span>{lang === 'hi' ? '▶️ GitHub से Netlify वीडियो (हिंदी)' : '▶️ GitHub to Netlify (Hindi)'}</span>
              <ExternalLink className="w-3.5 h-3.5 ml-auto" />
            </a>
          </div>
        </div>

        {/* Modal Close Button */}
        <div className="mt-4 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium transition"
          >
            {lang === 'hi' ? 'समझ गया / बंद करें' : 'Got it / Close'}
          </button>
        </div>
      </div>
    </div>
  );
};

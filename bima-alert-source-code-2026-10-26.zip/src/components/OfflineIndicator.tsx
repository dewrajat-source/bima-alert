import React from 'react';
import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export const OfflineIndicator: React.FC<{ lang: 'hi' | 'en' }> = ({ lang }) => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-600 px-3.5 py-2 text-xs font-semibold text-white shadow-xl shadow-amber-950/40 border border-amber-400/40 animate-pulse">
      <WifiOff className="w-4 h-4 shrink-0" />
      <span>
        {lang === 'hi' 
          ? 'ऑफ़लाइन मोड — सेव की गई सभी मोटर पॉलिसियां बिना इंटरनेट उपलब्ध हैं।' 
          : 'Offline Mode — All saved policies are cached locally.'}
      </span>
    </div>
  );
};

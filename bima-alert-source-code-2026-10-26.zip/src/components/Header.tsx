import React from 'react';
import { 
  ShieldCheck, 
  Smartphone, 
  Plus, 
  Bell, 
  Settings, 
  Volume2, 
  Languages, 
  CalendarClock
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { playAlertChime } from '../utils/reminderUtils';

interface Props {
  lang: 'hi' | 'en';
  onToggleLang: () => void;
  onOpenAddModal: () => void;
  onOpenSettings: () => void;
  onOpenInstallModal: () => void;
  onOpenVideoModal: () => void;
  urgentCount: number;
  expiredCount: number;
  agencyName: string;
}

export const Header: React.FC<Props> = ({
  lang,
  onToggleLang,
  onOpenAddModal,
  onOpenSettings,
  onOpenInstallModal,
  onOpenVideoModal,
  urgentCount,
  expiredCount,
  agencyName,
}) => {
  const { isInstalled, isInstallable } = usePWAInstall();

  const handleTestSound = () => {
    playAlertChime();
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-3">
        {/* Logo & Agency Branding */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-11 h-11 rounded-2xl bg-gradient-to-br from-blue-600 via-indigo-600 to-sky-500 shadow-md shadow-blue-500/20 text-white">
            <ShieldCheck className="w-6 h-6" />
            {(urgentCount > 0 || expiredCount > 0) && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-4 w-4 bg-rose-500 text-[9px] font-bold text-white items-center justify-center">
                  {urgentCount + expiredCount}
                </span>
              </span>
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                {lang === 'hi' ? 'बीमा रक्षक' : 'BimaAlert'}
              </h1>
              <span className="px-2 py-0.5 text-[11px] font-semibold rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                {lang === 'hi' ? 'मोटर पॉलिसी' : 'Motor Hub'}
              </span>
            </div>
            <p className="text-xs text-slate-400 font-medium truncate max-w-[200px] sm:max-w-xs">
              {agencyName || (lang === 'hi' ? 'मोटर पॉलिसी एक्सपायरी रिमाइंडर' : 'Motor Policy Expiry Reminder')}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Sound Alert Chime Test */}
          <button
            onClick={handleTestSound}
            title={lang === 'hi' ? 'अलर्ट घंटी बजाकर चेक करें' : 'Test reminder sound chime'}
            className="p-2 text-slate-400 hover:text-amber-400 hover:bg-slate-800 rounded-xl transition border border-slate-700/60"
            aria-label="Test Alert Tone"
          >
            <Volume2 className="w-4 h-4" />
          </button>

          {/* Language Toggle */}
          <button
            onClick={onToggleLang}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
            title="Switch Language / भाषा बदलें"
          >
            <Languages className="w-3.5 h-3.5 text-blue-400" />
            <span>{lang === 'hi' ? 'English' : 'हिंदी'}</span>
          </button>

          {/* Install App / APK / PC Button */}
          {!isInstalled && (
            <button
              onClick={onOpenInstallModal}
              className="relative flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 shadow-sm transition active:scale-95"
              title={lang === 'hi' ? 'फोन (APK) या कंप्यूटर (PC) में इंस्टॉल करें' : 'Install on Phone (APK) or PC'}
            >
              <Smartphone className="w-3.5 h-3.5 text-emerald-400 animate-bounce" />
              <span className="hidden xs:inline">
                {lang === 'hi' ? '📲 ऐप / PC इंस्टॉल' : '📲 Install App / PC'}
              </span>
              <span className="xs:hidden">
                {lang === 'hi' ? 'ऐप' : 'App'}
              </span>
            </button>
          )}

          {/* Watch Video Tutorial Button */}
          <button
            onClick={onOpenVideoModal}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-bold rounded-xl bg-red-600/20 hover:bg-red-600/30 text-red-300 border border-red-500/40 shadow-sm transition active:scale-95 animate-pulse"
            title={lang === 'hi' ? 'डाउनलोड करने का वीडियो देखें' : 'Watch Download & Install Video'}
          >
            <span className="text-sm">🎥</span>
            <span className="hidden sm:inline">
              {lang === 'hi' ? 'वीडियो देखें' : 'Video Guide'}
            </span>
            <span className="sm:hidden">
              {lang === 'hi' ? 'वीडियो' : 'Video'}
            </span>
          </button>

          {/* Settings Button */}
          <button
            onClick={onOpenSettings}
            title={lang === 'hi' ? 'सेटिंग्स और बैकअप' : 'Settings & Backup'}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition border border-slate-700/60"
            aria-label="Settings"
          >
            <Settings className="w-4 h-4" />
          </button>

          {/* Add Policy Button (Primary CTA) */}
          <button
            onClick={onOpenAddModal}
            className="flex items-center gap-1.5 px-3 sm:px-4 py-2 text-xs sm:text-sm font-semibold rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white shadow-md shadow-blue-500/25 transition active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>{lang === 'hi' ? 'नई पॉलिसी जोड़ें' : 'Add Policy'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};

import React from 'react';
import { 
  BellRing, 
  MessageCircle, 
  Phone, 
  CheckCircle, 
  Clock, 
  Calendar, 
  Sparkles, 
  ArrowLeft,
  Check,
  AlertTriangle
} from 'lucide-react';
import { AgentProfile, Policy } from '../types/policy';
import { formatDateIndian, getDaysRemaining, getUrgencyBadgeInfo } from '../utils/reminderUtils';
import { getCallUrl, getWhatsAppUrl } from '../utils/whatsapp';

interface Props {
  policies: Policy[];
  agent: AgentProfile;
  lang: 'hi' | 'en';
  onBack: () => void;
  onMarkReminded: (id: string) => void;
  onRenew: (policy: Policy) => void;
}

export const DailyRemindersView: React.FC<Props> = ({
  policies,
  agent,
  lang,
  onBack,
  onMarkReminded,
  onRenew,
}) => {
  // Filter policies that are either expired or expiring within next 7 days
  const urgentPolicies = policies
    .map(p => ({ policy: p, days: getDaysRemaining(p.policyExpiryDate) }))
    .filter(item => item.days <= 7)
    .sort((a, b) => a.days - b.days);

  const handleSendWhatsApp = (p: Policy) => {
    onMarkReminded(p.id);
    const url = getWhatsAppUrl(p, agent, lang);
    window.open(url, '_blank');
  };

  return (
    <div className="space-y-5">
      {/* Top Bar with Back Button */}
      <div className="flex items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{lang === 'hi' ? 'सभी पॉलिसियों पर वापस जाएं' : 'Back to All Policies'}</span>
        </button>

        <div className="text-right">
          <span className="text-xs text-slate-400">
            {lang === 'hi' ? 'आज की तारीख:' : 'Today:'}{' '}
            <span className="text-white font-medium">
              {new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
            </span>
          </span>
        </div>
      </div>

      {/* Header Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-blue-900/60 via-indigo-900/40 to-slate-900 border border-blue-500/30">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-600/30">
            <BellRing className="w-6 h-6 animate-bounce" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">
              {lang === 'hi' ? '🌅 आज के मोटर पॉलिसी रिमाइंडर हब' : '🌅 Daily Motor Renewal Reminders'}
            </h2>
            <p className="text-xs text-blue-200/80 mt-0.5">
              {lang === 'hi'
                ? `कुल ${urgentPolicies.length} गाड़ियाँ हैं जिनकी पॉलिसी समाप्त हो चुकी है या 7 दिनों के भीतर समाप्त होने वाली है।`
                : `${urgentPolicies.length} vehicle policies need renewal follow-up today.`}
            </p>
          </div>
        </div>
      </div>

      {/* List of Urgent Policies */}
      {urgentPolicies.length === 0 ? (
        <div className="text-center py-16 px-4 rounded-2xl bg-slate-800/40 border border-slate-700/60">
          <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-3">
            <CheckCircle className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-white">
            {lang === 'hi' ? 'बधाई! आज कोई भी पॉलिसी लंबित नहीं है' : 'Great Job! No Urgent Reminders Today'}
          </h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            {lang === 'hi'
              ? 'सभी ग्राहकों की पॉलिसी 7 दिनों से अधिक सुरक्षित हैं। नई पॉलिसी जोड़ने के लिए मुख्य पेज पर जाएं।'
              : 'All vehicle insurance policies are valid for over 7 days.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {urgentPolicies.map(({ policy, days }) => {
            const urgency = getUrgencyBadgeInfo(days, lang);
            const isSent = !!policy.lastReminderSentAt;

            return (
              <div
                key={policy.id}
                className={`p-4 rounded-2xl bg-slate-800/90 border transition hover:border-slate-600 flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${urgency.borderClass}`}
              >
                {/* Left Info */}
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Vehicle Plate */}
                    <div className="inline-flex items-center px-2 py-0.5 rounded-md bg-amber-400 text-slate-950 font-mono font-bold text-xs">
                      <span>{policy.vehicleNumber}</span>
                    </div>

                    <span className="font-semibold text-white text-sm">
                      {policy.customerName}
                    </span>

                    <span className={`px-2 py-0.5 rounded-md text-[11px] font-bold border ${urgency.badgeClass}`}>
                      {urgency.label}
                    </span>
                  </div>

                  <div className="text-xs text-slate-300 flex items-center gap-3 flex-wrap">
                    <span>🚗 {policy.vehicleMakeModel || 'वाहन'}</span>
                    <span>🏢 {policy.insuranceCompany}</span>
                    <span>💰 ₹{(policy.premiumAmount || 0).toLocaleString('en-IN')}</span>
                    <span className="text-slate-400">
                      📅 {lang === 'hi' ? 'एक्सपायरी:' : 'Expiry:'} <strong className="text-white">{formatDateIndian(policy.policyExpiryDate)}</strong>
                    </span>
                  </div>

                  {isSent && (
                    <div className="text-[11px] text-emerald-400 flex items-center gap-1 pt-0.5">
                      <Check className="w-3.5 h-3.5" />
                      <span>
                        {lang === 'hi' 
                          ? `रिमाइंडर भेजा जा चुका है (${new Date(policy.lastReminderSentAt!).toLocaleDateString('en-IN')})` 
                          : `Reminder sent on ${new Date(policy.lastReminderSentAt!).toLocaleDateString('en-IN')}`}
                      </span>
                    </div>
                  )}
                </div>

                {/* Right Actions */}
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => handleSendWhatsApp(policy)}
                    className="flex-1 sm:flex-none py-2 px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/30 transition active:scale-95"
                  >
                    <MessageCircle className="w-4 h-4 fill-white text-emerald-600" />
                    <span>{lang === 'hi' ? 'व्हाट्सएप भेजें' : 'Send WhatsApp'}</span>
                  </button>

                  <a
                    href={getCallUrl(policy.customerPhone)}
                    className="p-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-blue-400 hover:text-white transition"
                    title="Call"
                  >
                    <Phone className="w-4 h-4" />
                  </a>

                  <button
                    onClick={() => onRenew(policy)}
                    className="py-2 px-3 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 hover:text-white border border-blue-500/40 text-xs font-semibold transition"
                  >
                    {lang === 'hi' ? 'रिन्यू' : 'Renew'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

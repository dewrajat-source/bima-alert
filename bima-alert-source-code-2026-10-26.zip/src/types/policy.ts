export type VehicleType = 
  | 'two_wheeler'
  | 'four_wheeler'
  | 'commercial'
  | 'taxi'
  | 'auto'
  | 'tractor'
  | 'other';

export type PolicyType = 'comprehensive' | 'third_party' | 'standalone_od';

export type ExpiryUrgency = 'expired' | 'today' | 'critical' | 'upcoming' | 'safe';

export interface RenewalHistoryItem {
  id: string;
  previousPolicyNumber: string;
  renewedDate: string;
  newExpiryDate: string;
  premiumAmount: number;
  insuranceCompany: string;
}

export interface Policy {
  id: string;
  customerName: string;
  customerPhone: string;
  alternatePhone?: string;
  customerEmail?: string;
  customerCity?: string;
  vehicleNumber: string; // e.g. RJ 14 CA 1234
  vehicleType: VehicleType;
  vehicleMakeModel: string; // e.g. Maruti Suzuki Swift / Hero Splendor
  insuranceCompany: string; // e.g. Tata AIG, HDFC Ergo, ICICI Lombard
  policyNumber: string;
  policyType: PolicyType;
  premiumAmount: number;
  policyStartDate: string; // YYYY-MM-DD
  policyExpiryDate: string; // YYYY-MM-DD
  previousNCB: number; // 0, 20, 25, 35, 45, 50
  reminderDaysBefore: number[]; // e.g. [30, 15, 7, 3, 1, 0]
  isFinanced?: boolean;
  financeBank?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  lastReminderSentAt?: string;
  reminderCount?: number;
  renewalHistory?: RenewalHistoryItem[];
}

export interface AgentProfile {
  agentName: string;
  agencyName: string;
  phone: string;
  email?: string;
  city: string;
  whatsappTemplateHindi: string;
  whatsappTemplateEnglish: string;
  preferredLanguage: 'hi' | 'en';
  autoNotificationEnabled: boolean;
}

import { ExpiryUrgency, Policy } from '../types/policy';

/**
 * Calculates days remaining until the policy expiry date.
 * Returns negative if expired, 0 if expires today, positive if in future.
 */
export function getDaysRemaining(expiryDateStr: string): number {
  if (!expiryDateStr) return 0;
  
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [year, month, day] = expiryDateStr.split('-').map(Number);
  const expiry = new Date(year, month - 1, day);
  expiry.setHours(0, 0, 0, 0);

  const diffTime = expiry.getTime() - today.getTime();
  const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
}

export function getExpiryUrgency(daysRemaining: number): ExpiryUrgency {
  if (daysRemaining < 0) return 'expired';
  if (daysRemaining === 0) return 'today';
  if (daysRemaining <= 7) return 'critical';
  if (daysRemaining <= 30) return 'upcoming';
  return 'safe';
}

export function getUrgencyBadgeInfo(daysRemaining: number, lang: 'hi' | 'en' = 'hi'): {
  label: string;
  badgeClass: string;
  borderClass: string;
  bgLightClass: string;
  iconType: 'alert-triangle' | 'clock' | 'check' | 'x-circle';
} {
  const urgency = getExpiryUrgency(daysRemaining);

  switch (urgency) {
    case 'expired': {
      const days = Math.abs(daysRemaining);
      return {
        label: lang === 'hi' 
          ? `${days} दिन पहले समाप्त` 
          : `Expired ${days}d ago`,
        badgeClass: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
        borderClass: 'border-rose-500/40',
        bgLightClass: 'bg-rose-950/20',
        iconType: 'x-circle',
      };
    }
    case 'today':
      return {
        label: lang === 'hi' ? '🚨 आज समाप्त हो रही है!' : '🚨 Expires Today!',
        badgeClass: 'bg-red-600 text-white font-bold animate-pulse shadow-red-500/50 shadow-md',
        borderClass: 'border-red-500',
        bgLightClass: 'bg-red-950/30',
        iconType: 'alert-triangle',
      };
    case 'critical':
      return {
        label: lang === 'hi' 
          ? `⚠️ केवल ${daysRemaining} दिन शेष` 
          : `⚠️ Only ${daysRemaining} days left`,
        badgeClass: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
        borderClass: 'border-amber-500/40',
        bgLightClass: 'bg-amber-950/20',
        iconType: 'alert-triangle',
      };
    case 'upcoming':
      return {
        label: lang === 'hi' 
          ? `${daysRemaining} दिन शेष` 
          : `${daysRemaining} days left`,
        badgeClass: 'bg-sky-500/20 text-sky-300 border-sky-500/40',
        borderClass: 'border-sky-500/30',
        bgLightClass: 'bg-sky-950/10',
        iconType: 'clock',
      };
    case 'safe':
    default:
      return {
        label: lang === 'hi' 
          ? `सुरक्षित (${daysRemaining} दिन)` 
          : `Active (${daysRemaining} days)`,
        badgeClass: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
        borderClass: 'border-emerald-500/30',
        bgLightClass: 'bg-emerald-950/10',
        iconType: 'check',
      };
  }
}

/**
 * Format YYYY-MM-DD to Indian DD/MM/YYYY
 */
export function formatDateIndian(dateStr: string): string {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  }
  return dateStr;
}

/**
 * Normalize and auto-format vehicle numbers e.g. "rj14ca1234" -> "RJ 14 CA 1234"
 */
export function formatVehicleNumber(num: string): string {
  if (!num) return '';
  const clean = num.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
  if (clean.length >= 8 && clean.length <= 11) {
    // Check Indian format: State(2) + RTO(2) + Series(1-3) + Number(4)
    const match = clean.match(/^([A-Z]{2})(\d{2})([A-Z]{1,3})(\d{1,4})$/);
    if (match) {
      return `${match[1]} ${match[2]} ${match[3]} ${match[4]}`;
    }
  }
  return clean;
}

/**
 * Play a notification alert tone using Web Audio API
 */
export function playAlertChime() {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(587.33, now); // D5
    osc.frequency.exponentialRampToValueAtTime(880, now + 0.15); // A5

    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + 0.35);
  } catch (e) {
    console.warn('Audio alert unavailable', e);
  }
}

/**
 * Request notification permission and send reminder notification if allowed
 */
export async function requestAndSendNotification(policies: Policy[]) {
  if (!('Notification' in window)) return;

  let perm = Notification.permission;
  if (perm === 'default') {
    perm = await Notification.requestPermission();
  }

  if (perm === 'granted') {
    const criticalPolicies = policies.filter(p => {
      const days = getDaysRemaining(p.policyExpiryDate);
      return days >= 0 && days <= 7;
    });

    if (criticalPolicies.length > 0) {
      const title = `🚨 ${criticalPolicies.length} मोटर पॉलिसी एक्सपायरी अलर्ट!`;
      const body = criticalPolicies.length === 1 
        ? `${criticalPolicies[0].customerName} (${criticalPolicies[0].vehicleNumber}) की पॉलिसी ${getDaysRemaining(criticalPolicies[0].policyExpiryDate)} दिन में समाप्त हो रही है।`
        : `कुल ${criticalPolicies.length} गाड़ियाँ 7 दिनों के भीतर रिन्यूअल के लिए लंबित हैं।`;

      new Notification(title, {
        body,
        icon: '/icon.svg',
        badge: '/pwa-192x192.png',
      });
    }
  }
}

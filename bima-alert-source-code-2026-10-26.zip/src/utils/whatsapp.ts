import { AgentProfile, Policy } from '../types/policy';
import { formatDateIndian, getDaysRemaining } from './reminderUtils';

/**
 * Builds the personalized WhatsApp reminder message
 */
export function buildWhatsAppMessage(
  policy: Policy,
  agent: AgentProfile,
  language: 'hi' | 'en' = 'hi'
): string {
  const days = getDaysRemaining(policy.policyExpiryDate);
  const formattedExpiry = formatDateIndian(policy.policyExpiryDate);

  let urgencyTextHi = '';
  let urgencyTextEn = '';

  if (days < 0) {
    urgencyTextHi = `⚠️ आपकी पॉलिसी ${Math.abs(days)} दिन पहले समाप्त (Expired) हो चुकी है!`;
    urgencyTextEn = `⚠️ Your policy has expired ${Math.abs(days)} days ago!`;
  } else if (days === 0) {
    urgencyTextHi = `🚨 आज आपकी पॉलिसी समाप्त (Expires Today) हो रही है!`;
    urgencyTextEn = `🚨 Your policy expires today!`;
  } else if (days === 1) {
    urgencyTextHi = `⏳ केवल 1 दिन बाकी है (कल समाप्त हो जाएगी)!`;
    urgencyTextEn = `⏳ Only 1 day remaining (expires tomorrow)!`;
  } else {
    urgencyTextHi = `⏳ केवल ${days} दिन शेष हैं!`;
    urgencyTextEn = `⏳ Only ${days} days remaining!`;
  }

  if (language === 'hi') {
    return (
`*नमस्ते ${policy.customerName} जी,* 🙏

यह एक महत्वपूर्ण सूचना है कि आपके वाहन की मोटर बीमा पॉलिसी शीघ्र समाप्त हो रही है:

🚗 *वाहन:* ${policy.vehicleNumber} (${policy.vehicleMakeModel || 'गाड़ी'})
📋 *पॉलिसी नंबर:* ${policy.policyNumber || 'N/A'}
🏢 *बीमा कंपनी:* ${policy.insuranceCompany}
📅 *समाप्ति तिथि (Expiry):* ${formattedExpiry}
${urgencyTextHi}

⚠️ *ध्यान दें:*
• बिना वैध बीमा गाड़ी चलाने पर ₹2,000/- से ₹4,000/- तक का भारी चालान हो सकता है।
• समय पर रिन्यू कराने से आपका *नो क्लेम बोनस (NCB ${policy.previousNCB || 0}%)* सुरक्षित रहेगा और आपको प्रीमियम में भारी छूट मिलेगी।
• किसी भी दुर्घटना की स्थिति में वित्तीय सुरक्षा बनी रहेगी।

📲 *कृपया बिना रुकावट और पेनल्टी से बचने के लिए तुरंत रिन्यू कराएं।*
आप इस मैसेज का उत्तर देकर या सीधे कॉल करके तुरंत पॉलिसी रिन्यू करा सकते हैं।

सादर,
*${agent.agentName}*
*${agent.agencyName}*
📞 संपर्क: ${agent.phone}
${agent.city ? `📍 ${agent.city}` : ''}`
    );
  } else {
    return (
`*Dear ${policy.customerName},*

This is an important reminder regarding the expiry of your vehicle motor insurance:

🚗 *Vehicle:* ${policy.vehicleNumber} (${policy.vehicleMakeModel || 'Vehicle'})
📋 *Policy No:* ${policy.policyNumber || 'N/A'}
🏢 *Insurer:* ${policy.insuranceCompany}
📅 *Expiry Date:* ${formattedExpiry}
${urgencyTextEn}

⚠️ *Important Note:*
• Driving without valid insurance attracts heavy traffic fines (up to ₹4,000).
• Renew before expiry to retain your *No Claim Bonus (NCB ${policy.previousNCB || 0}%)* and get discount on premium.
• Continuous coverage ensures peace of mind against road mishaps.

📲 *Please renew today to avoid penalty and policy lapse.*
Reply to this message or call directly to get instant renewal with best quotes.

Regards,
*${agent.agentName}*
*${agent.agencyName}*
📞 Phone: ${agent.phone}
${agent.city ? `📍 ${agent.city}` : ''}`
    );
  }
}

/**
 * Clean phone number to Indian standard 91XXXXXXXXXX
 */
export function cleanPhoneNumber(phone: string): string {
  if (!phone) return '';
  const digits = phone.replace(/\D/g, '');
  if (digits.length === 10) {
    return `91${digits}`;
  }
  if (digits.length === 11 && digits.startsWith('0')) {
    return `91${digits.slice(1)}`;
  }
  if (digits.length === 12 && digits.startsWith('91')) {
    return digits;
  }
  return digits;
}

/**
 * Generate WhatsApp Click to Chat URL
 */
export function getWhatsAppUrl(policy: Policy, agent: AgentProfile, language: 'hi' | 'en' = 'hi'): string {
  const phone = cleanPhoneNumber(policy.customerPhone);
  const message = buildWhatsAppMessage(policy, agent, language);
  const encoded = encodeURIComponent(message);
  return `https://wa.me/${phone}?text=${encoded}`;
}

/**
 * Direct phone call link
 */
export function getCallUrl(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  return `tel:${digits}`;
}

/**
 * Direct SMS link
 */
export function getSmsUrl(policy: Policy, agent: AgentProfile, language: 'hi' | 'en' = 'hi'): string {
  const digits = cleanPhoneNumber(policy.customerPhone);
  const message = buildWhatsAppMessage(policy, agent, language);
  return `sms:${digits}?body=${encodeURIComponent(message)}`;
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  Plus, 
  Smartphone, 
  CalendarClock, 
  Car, 
  Bike, 
  Truck, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Shield, 
  Share2, 
  HelpCircle,
  FileText,
  Send,
  X
} from 'lucide-react';
import { Policy, AgentProfile, VehicleType } from './types/policy';
import { StorageService } from './services/storage';
import { getDaysRemaining, requestAndSendNotification } from './utils/reminderUtils';
import { Header } from './components/Header';
import { DashboardStats } from './components/DashboardStats';
import { PolicyCard } from './components/PolicyCard';
import { PolicyFormModal } from './components/PolicyFormModal';
import { RenewModal } from './components/RenewModal';
import { DailyRemindersView } from './components/DailyRemindersView';
import { SettingsModal } from './components/SettingsModal';
import { PWAInstallModal } from './components/PWAInstallModal';
import { InstallVideoModal } from './components/InstallVideoModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { usePWAInstall } from './hooks/usePWAInstall';

export default function App() {
  const [policies, setPolicies] = useState<Policy[]>([]);
  const [agentProfile, setAgentProfile] = useState<AgentProfile>(() => StorageService.getAgentProfile());
  const [lang, setLang] = useState<'hi' | 'en'>(agentProfile.preferredLanguage || 'hi');
  const [activeTab, setActiveTab] = useState<'all' | 'daily'>('all');
  const [urgencyFilter, setUrgencyFilter] = useState<string>('all');
  const [vehicleFilter, setVehicleFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'expiry_asc' | 'expiry_desc' | 'name' | 'premium'>('expiry_asc');

  // Modals
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [policyToEdit, setPolicyToEdit] = useState<Policy | null>(null);
  const [policyToRenew, setPolicyToRenew] = useState<Policy | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isInstallOpen, setIsInstallOpen] = useState(false);
  const [isVideoOpen, setIsVideoOpen] = useState(false);

  const { isInstalled, isInstallable, install } = usePWAInstall();

  // Load policies from Storage
  useEffect(() => {
    const loaded = StorageService.getPolicies();
    setPolicies(loaded);

    // Trigger check for urgent notifications if permitted
    if (loaded.length > 0) {
      requestAndSendNotification(loaded);
    }
  }, []);

  const handleToggleLang = () => {
    const nextLang: 'hi' | 'en' = lang === 'hi' ? 'en' : 'hi';
    setLang(nextLang);
    const updated: AgentProfile = { ...agentProfile, preferredLanguage: nextLang };
    setAgentProfile(updated);
    StorageService.saveAgentProfile(updated);
  };

  const handleSavePolicy = (data: Omit<Policy, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (policyToEdit) {
      const updated = StorageService.updatePolicy(policyToEdit.id, data);
      if (updated) {
        setPolicies(StorageService.getPolicies());
      }
      setPolicyToEdit(null);
    } else {
      StorageService.addPolicy(data);
      setPolicies(StorageService.getPolicies());
    }
  };

  const handleDeletePolicy = (id: string) => {
    const confirmMsg = lang === 'hi' 
      ? 'क्या आप वाकई इस ग्राहक की पॉलिसी को हटाना चाहते हैं?' 
      : 'Are you sure you want to delete this policy record?';
    if (window.confirm(confirmMsg)) {
      StorageService.deletePolicy(id);
      setPolicies(StorageService.getPolicies());
    }
  };

  const handleRenewConfirm = (id: string, newPolicyNo: string, newPremium: number, newInsurer?: string) => {
    StorageService.renewPolicy(id, newPolicyNo, newPremium, newInsurer);
    setPolicies(StorageService.getPolicies());
    setPolicyToRenew(null);
  };

  const handleMarkReminded = (id: string) => {
    StorageService.markReminderSent(id);
    setPolicies(StorageService.getPolicies());
  };

  const handleSaveAgent = (profile: AgentProfile) => {
    setAgentProfile(profile);
    StorageService.saveAgentProfile(profile);
  };

  const urgentCount = useMemo(() => {
    return policies.filter(p => {
      const days = getDaysRemaining(p.policyExpiryDate);
      return days >= 0 && days <= 7;
    }).length;
  }, [policies]);

  const expiredCount = useMemo(() => {
    return policies.filter(p => getDaysRemaining(p.policyExpiryDate) < 0).length;
  }, [policies]);

  // Filter and sort policies
  const filteredPolicies = useMemo(() => {
    let result = [...policies];

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(p => 
        p.customerName.toLowerCase().includes(q) ||
        p.vehicleNumber.toLowerCase().replace(/\s+/g, '').includes(q.replace(/\s+/g, '')) ||
        p.customerPhone.includes(q) ||
        p.policyNumber.toLowerCase().includes(q) ||
        p.insuranceCompany.toLowerCase().includes(q) ||
        (p.vehicleMakeModel && p.vehicleMakeModel.toLowerCase().includes(q))
      );
    }

    // Urgency filter
    if (urgencyFilter !== 'all') {
      result = result.filter(p => {
        const days = getDaysRemaining(p.policyExpiryDate);
        if (urgencyFilter === 'expired') return days < 0;
        if (urgencyFilter === 'critical') return days >= 0 && days <= 7;
        if (urgencyFilter === 'upcoming') return days > 7 && days <= 30;
        if (urgencyFilter === 'safe') return days > 30;
        return true;
      });
    }

    // Vehicle Type filter
    if (vehicleFilter !== 'all') {
      result = result.filter(p => p.vehicleType === vehicleFilter);
    }

    // Sorting
    result.sort((a, b) => {
      const daysA = getDaysRemaining(a.policyExpiryDate);
      const daysB = getDaysRemaining(b.policyExpiryDate);

      switch (sortBy) {
        case 'expiry_asc':
          return daysA - daysB;
        case 'expiry_desc':
          return daysB - daysA;
        case 'name':
          return a.customerName.localeCompare(b.customerName);
        case 'premium':
          return (b.premiumAmount || 0) - (a.premiumAmount || 0);
        default:
          return daysA - daysB;
      }
    });

    return result;
  }, [policies, searchQuery, urgencyFilter, vehicleFilter, sortBy]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top App Header */}
      <Header
        lang={lang}
        onToggleLang={handleToggleLang}
        onOpenAddModal={() => { setPolicyToEdit(null); setIsFormOpen(true); }}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenInstallModal={() => setIsInstallOpen(true)}
        onOpenVideoModal={() => setIsVideoOpen(true)}
        urgentCount={urgentCount}
        expiredCount={expiredCount}
        agencyName={agentProfile.agencyName}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-5 space-y-6">
        {/* Navigation Tabs (Dashboard vs Daily Reminders) */}
        <div className="flex items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition ${
                activeTab === 'all'
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {lang === 'hi' ? 'सभी पॉलिसियां (डैशबोर्ड)' : 'All Policies (Dashboard)'}
            </button>
            <button
              onClick={() => setActiveTab('daily')}
              className={`relative px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition flex items-center gap-2 ${
                activeTab === 'daily'
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Send className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'आज के फॉलो-अप रिमाइंडर' : 'Today Reminders'}</span>
              {(urgentCount > 0 || expiredCount > 0) && (
                <span className="px-1.5 py-0.2 rounded-full bg-white text-rose-700 text-[10px] font-extrabold">
                  {urgentCount + expiredCount}
                </span>
              )}
            </button>
          </div>

          {/* Quick Install APK Prompt Banner for Mobile */}
          {!isInstalled && (
            <button
              onClick={() => setIsInstallOpen(true)}
              className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs text-slate-300 font-medium transition"
            >
              <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
              <span>{lang === 'hi' ? 'फोन में APK की तरह चलाएं' : 'Run as Mobile App'}</span>
            </button>
          )}
        </div>

        {activeTab === 'daily' ? (
          <DailyRemindersView
            policies={policies}
            agent={agentProfile}
            lang={lang}
            onBack={() => setActiveTab('all')}
            onMarkReminded={handleMarkReminded}
            onRenew={(p) => setPolicyToRenew(p)}
          />
        ) : (
          <div className="space-y-6">
            {/* Dashboard Metrics and Expiry Banner */}
            <DashboardStats
              policies={policies}
              lang={lang}
              activeFilter={urgencyFilter}
              onSelectFilter={(filter) => setUrgencyFilter(filter)}
              onNavigateToDaily={() => setActiveTab('daily')}
            />

            {/* Search, Filter Bar and Sorting */}
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800/90 space-y-3.5">
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                {/* Search Bar */}
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    placeholder={lang === 'hi' ? 'गाड़ी नंबर (उदा. RJ 14), ग्राहक का नाम, मोबाइल नंबर से खोजें...' : 'Search by vehicle plate, customer name, phone, policy...'}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-slate-800 border border-slate-700 focus:border-blue-500 text-white text-xs sm:text-sm placeholder:text-slate-500 outline-hidden"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3 top-3 text-slate-500 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Sort Dropdown */}
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-xs text-slate-400 hidden sm:inline">
                    {lang === 'hi' ? 'क्रम:' : 'Sort:'}
                  </span>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as 'expiry_asc' | 'expiry_desc' | 'name' | 'premium')}
                    className="px-3 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-hidden cursor-pointer"
                  >
                    <option value="expiry_asc">{lang === 'hi' ? 'एक्सपायरी (जल्द समाप्त पहले)' : 'Expiry (Soonest first)'}</option>
                    <option value="expiry_desc">{lang === 'hi' ? 'एक्सपायरी (देर से समाप्त)' : 'Expiry (Furthest)'}</option>
                    <option value="name">{lang === 'hi' ? 'ग्राहक नाम (A-Z)' : 'Customer Name'}</option>
                    <option value="premium">{lang === 'hi' ? 'प्रीमियम राशि (अधिक से कम)' : 'Premium (High to Low)'}</option>
                  </select>
                </div>
              </div>

              {/* Vehicle Type Filter Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
                <span className="text-slate-500 text-[11px] shrink-0 mr-1">
                  {lang === 'hi' ? 'वाहन:' : 'Vehicle:'}
                </span>

                {[
                  { id: 'all', label: lang === 'hi' ? 'सभी प्रकार' : 'All Types' },
                  { id: 'four_wheeler', label: lang === 'hi' ? 'कार / 4-व्हीलर' : 'Car (4W)', icon: Car },
                  { id: 'two_wheeler', label: lang === 'hi' ? 'बाइक / स्कूटर' : 'Bike (2W)', icon: Bike },
                  { id: 'commercial', label: lang === 'hi' ? 'कमर्शियल' : 'Commercial', icon: Truck },
                  { id: 'taxi', label: lang === 'hi' ? 'टैक्सी' : 'Taxi' },
                ].map(item => {
                  const isSelected = vehicleFilter === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setVehicleFilter(item.id)}
                      className={`px-3 py-1.5 rounded-xl font-medium transition whitespace-nowrap flex items-center gap-1.5 ${
                        isSelected
                          ? 'bg-blue-600 text-white font-semibold'
                          : 'bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-800'
                      }`}
                    >
                      {item.icon && <item.icon className="w-3.5 h-3.5" />}
                      <span>{item.label}</span>
                    </button>
                  );
                })}

                {/* Clear Filters button if filters are active */}
                {(urgencyFilter !== 'all' || vehicleFilter !== 'all' || searchQuery) && (
                  <button
                    onClick={() => {
                      setUrgencyFilter('all');
                      setVehicleFilter('all');
                      setSearchQuery('');
                    }}
                    className="ml-auto text-[11px] text-rose-400 hover:text-rose-300 font-semibold px-2 py-1 underline whitespace-nowrap"
                  >
                    {lang === 'hi' ? 'फ़िल्टर हटाएं' : 'Reset filters'}
                  </button>
                )}
              </div>
            </div>

            {/* Policy List Grid */}
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                <span>
                  {lang === 'hi' 
                    ? `दिखाई जा रही पॉलिसियां: ${filteredPolicies.length} / कुल ${policies.length}` 
                    : `Showing ${filteredPolicies.length} of ${policies.length} policies`}
                </span>
                {urgencyFilter !== 'all' && (
                  <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 capitalize">
                    {lang === 'hi' ? `फ़िल्टर: ${urgencyFilter}` : `Filter: ${urgencyFilter}`}
                  </span>
                )}
              </div>

              {filteredPolicies.length === 0 ? (
                <div className="text-center py-16 px-4 rounded-2xl bg-slate-900/40 border border-slate-800">
                  <div className="w-14 h-14 rounded-2xl bg-slate-800 text-slate-500 flex items-center justify-center mx-auto mb-3">
                    <Search className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-white">
                    {lang === 'hi' ? 'कोई रिकॉर्ड नहीं मिला' : 'No Policies Found'}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                    {lang === 'hi'
                      ? 'अपनी खोज या फ़िल्टर बदलकर देखें अथवा नए ग्राहक की पॉलिसी जोड़ें।'
                      : 'Try adjusting your search criteria or add a new customer policy.'}
                  </p>
                  <button
                    onClick={() => { setPolicyToEdit(null); setIsFormOpen(true); }}
                    className="mt-4 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold inline-flex items-center gap-1.5 shadow-md shadow-blue-600/30"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{lang === 'hi' ? 'नई पॉलिसी जोड़ें' : 'Add Policy Now'}</span>
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredPolicies.map(policy => (
                    <PolicyCard
                      key={policy.id}
                      policy={policy}
                      agent={agentProfile}
                      lang={lang}
                      onEdit={(p) => { setPolicyToEdit(p); setIsFormOpen(true); }}
                      onDelete={handleDeletePolicy}
                      onRenew={(p) => setPolicyToRenew(p)}
                      onMarkReminded={handleMarkReminded}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Floating Add Policy Button for Quick Mobile Access */}
      <div className="fixed bottom-6 right-6 z-30">
        <button
          onClick={() => { setPolicyToEdit(null); setIsFormOpen(true); }}
          className="flex items-center gap-2 py-3 px-5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm shadow-xl shadow-blue-500/40 border border-blue-400/30 transition active:scale-95"
          title={lang === 'hi' ? 'नया ग्राहक सेव करें' : 'Add New Motor Policy'}
        >
          <Plus className="w-5 h-5 stroke-[2.5]" />
          <span>{lang === 'hi' ? 'नई पॉलिसी' : 'New Policy'}</span>
        </button>
      </div>

      {/* Offline Status Indicator */}
      <OfflineIndicator lang={lang} />

      {/* Modals */}
      <PolicyFormModal
        isOpen={isFormOpen}
        onClose={() => { setIsFormOpen(false); setPolicyToEdit(null); }}
        onSave={handleSavePolicy}
        policyToEdit={policyToEdit}
        lang={lang}
      />

      <RenewModal
        isOpen={!!policyToRenew}
        onClose={() => setPolicyToRenew(null)}
        policy={policyToRenew}
        onConfirmRenewal={handleRenewConfirm}
        lang={lang}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        agent={agentProfile}
        onSaveAgent={handleSaveAgent}
        lang={lang}
        onRefreshPolicies={() => setPolicies(StorageService.getPolicies())}
      />

      <PWAInstallModal
        isOpen={isInstallOpen}
        onClose={() => setIsInstallOpen(false)}
        lang={lang}
        onOpenVideoModal={() => setIsVideoOpen(true)}
      />

      <InstallVideoModal
        isOpen={isVideoOpen}
        onClose={() => setIsVideoOpen(false)}
        lang={lang}
      />
    </div>
  );
}

import { AgentProfile, Policy, RenewalHistoryItem } from '../types/policy';

const POLICIES_STORAGE_KEY = 'bima_alert_policies_v1';
const AGENT_STORAGE_KEY = 'bima_alert_agent_profile_v1';

// Seed initial realistic policies relative to today's date
function getInitialSamplePolicies(): Policy[] {
  const now = new Date();
  
  const formatDateOffset = (daysOffset: number): string => {
    const d = new Date(now);
    d.setDate(d.getDate() + daysOffset);
    return d.toISOString().split('T')[0];
  };

  const formatPastDateOffset = (daysOffset: number): string => {
    const d = new Date(now);
    d.setDate(d.getDate() - 365 + daysOffset);
    return d.toISOString().split('T')[0];
  };

  return [
    {
      id: 'pol-1',
      customerName: 'राहुल शर्मा (Rahul Sharma)',
      customerPhone: '9829012345',
      customerCity: 'Jaipur, Rajasthan',
      vehicleNumber: 'RJ 14 CA 5678',
      vehicleType: 'four_wheeler',
      vehicleMakeModel: 'Maruti Suzuki Swift VXi',
      insuranceCompany: 'TATA AIG General Insurance',
      policyNumber: 'OG-25-1102-1801-00045211',
      policyType: 'comprehensive',
      premiumAmount: 6450,
      policyStartDate: formatPastDateOffset(2),
      policyExpiryDate: formatDateOffset(2), // Expiring in 2 days! Critical
      previousNCB: 25,
      reminderDaysBefore: [30, 15, 7, 3, 1, 0],
      isFinanced: true,
      financeBank: 'SBI Car Loan',
      notes: 'Customer asked for quick WhatsApp renewal quote with 24x7 roadside assistance add-on.',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      reminderCount: 1,
      lastReminderSentAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    },
    {
      id: 'pol-2',
      customerName: 'अमित कुमार वर्मा (Amit Verma)',
      customerPhone: '9414023456',
      customerCity: 'Jaipur, Rajasthan',
      vehicleNumber: 'RJ 14 SK 9081',
      vehicleType: 'two_wheeler',
      vehicleMakeModel: 'Hero Splendor Plus i3S',
      insuranceCompany: 'HDFC ERGO General Insurance',
      policyNumber: '2311-2045-8891-00',
      policyType: 'third_party',
      premiumAmount: 1140,
      policyStartDate: formatPastDateOffset(0),
      policyExpiryDate: formatDateOffset(0), // Today!
      previousNCB: 0,
      reminderDaysBefore: [15, 7, 3, 1, 0],
      isFinanced: false,
      notes: 'Need renewal today to avoid traffic fine.',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'pol-3',
      customerName: 'सुनील सिंह शेखावत (Sunil Shekhawat)',
      customerPhone: '9828134567',
      customerCity: 'Sikar Road, Jaipur',
      vehicleNumber: 'RJ 14 GC 3421',
      vehicleType: 'commercial',
      vehicleMakeModel: 'Tata Ace Gold (Chhota Hathi)',
      insuranceCompany: 'The New India Assurance Co.',
      policyNumber: '33020031240100008452',
      policyType: 'comprehensive',
      premiumAmount: 14850,
      policyStartDate: formatPastDateOffset(5),
      policyExpiryDate: formatDateOffset(5), // 5 days left
      previousNCB: 35,
      reminderDaysBefore: [30, 15, 7, 3, 0],
      isFinanced: true,
      financeBank: 'HDFC Bank Auto Loan',
      notes: 'Commercial vehicle fitness and permit check required too.',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'pol-4',
      customerName: 'प्रिया मेहरा (Priya Mehra)',
      customerPhone: '9784567890',
      customerCity: 'Mansarovar, Jaipur',
      vehicleNumber: 'RJ 14 EV 4410',
      vehicleType: 'four_wheeler',
      vehicleMakeModel: 'Tata Nexon EV Max',
      insuranceCompany: 'Go Digit General Insurance',
      policyNumber: 'D08912344-ODTP',
      policyType: 'comprehensive',
      premiumAmount: 11200,
      policyStartDate: formatPastDateOffset(-3),
      policyExpiryDate: formatDateOffset(-3), // Expired 3 days ago!
      previousNCB: 20,
      reminderDaysBefore: [30, 15, 7, 1, 0],
      notes: 'Lapsed 3 days ago. Needs vehicle self-inspection video link before renewal.',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'pol-5',
      customerName: 'महेश चौधरी (Mahesh Choudhary)',
      customerPhone: '9829988776',
      customerCity: 'Ajmer Road, Jaipur',
      vehicleNumber: 'RJ 14 CC 8822',
      vehicleType: 'four_wheeler',
      vehicleMakeModel: 'Hyundai Creta 1.5 SX',
      insuranceCompany: 'ICICI Lombard General Insurance',
      policyNumber: '3001/22904812/00/000',
      policyType: 'comprehensive',
      premiumAmount: 13900,
      policyStartDate: formatPastDateOffset(18),
      policyExpiryDate: formatDateOffset(18), // 18 days left (Upcoming)
      previousNCB: 45,
      reminderDaysBefore: [30, 15, 7, 3, 0],
      isFinanced: false,
      notes: 'High NCB 45%. Remind for zero-depreciation and engine protect cover.',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'pol-6',
      customerName: 'विष्णु कुमावत (Vishnu Kumawat)',
      customerPhone: '9660112233',
      customerCity: 'Tonk Road, Jaipur',
      vehicleNumber: 'RJ 14 AB 1109',
      vehicleType: 'two_wheeler',
      vehicleMakeModel: 'Honda Activa 6G',
      insuranceCompany: 'Bajaj Allianz General Insurance',
      policyNumber: 'OG-25-1801-1802-00099182',
      policyType: 'comprehensive',
      premiumAmount: 1850,
      policyStartDate: formatPastDateOffset(160),
      policyExpiryDate: formatDateOffset(160), // Active, safe (160 days)
      previousNCB: 20,
      reminderDaysBefore: [30, 15, 7, 1, 0],
      notes: 'Regular customer. Always pays via PhonePe/UPI.',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
  ];
}

const DEFAULT_AGENT_PROFILE: AgentProfile = {
  agentName: 'रजत जी (Rajat Ji)',
  agencyName: 'रजत कम्प्यूटर्स & मोटर इंश्योरेंस',
  phone: '9829012345',
  email: 'rajatcomputersjaipur@gmail.com',
  city: 'जयपुर (Jaipur), राजस्थान',
  whatsappTemplateHindi: '',
  whatsappTemplateEnglish: '',
  preferredLanguage: 'hi',
  autoNotificationEnabled: true,
};

export const StorageService = {
  getPolicies(): Policy[] {
    try {
      const data = localStorage.getItem(POLICIES_STORAGE_KEY);
      if (!data) {
        const initial = getInitialSamplePolicies();
        localStorage.setItem(POLICIES_STORAGE_KEY, JSON.stringify(initial));
        return initial;
      }
      return JSON.parse(data);
    } catch (e) {
      console.error('Failed to parse policies from localStorage', e);
      return getInitialSamplePolicies();
    }
  },

  savePolicies(policies: Policy[]): void {
    try {
      localStorage.setItem(POLICIES_STORAGE_KEY, JSON.stringify(policies));
    } catch (e) {
      console.error('Failed to save policies to localStorage', e);
    }
  },

  addPolicy(policy: Omit<Policy, 'id' | 'createdAt' | 'updatedAt'>): Policy {
    const policies = this.getPolicies();
    const newPolicy: Policy = {
      ...policy,
      id: `pol-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      reminderCount: 0,
    };
    policies.unshift(newPolicy);
    this.savePolicies(policies);
    return newPolicy;
  },

  updatePolicy(id: string, updates: Partial<Policy>): Policy | null {
    const policies = this.getPolicies();
    const index = policies.findIndex(p => p.id === id);
    if (index === -1) return null;

    policies[index] = {
      ...policies[index],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.savePolicies(policies);
    return policies[index];
  },

  deletePolicy(id: string): boolean {
    const policies = this.getPolicies();
    const filtered = policies.filter(p => p.id !== id);
    if (filtered.length === policies.length) return false;
    this.savePolicies(filtered);
    return true;
  },

  markReminderSent(id: string): void {
    const policies = this.getPolicies();
    const index = policies.findIndex(p => p.id === id);
    if (index !== -1) {
      policies[index].lastReminderSentAt = new Date().toISOString();
      policies[index].reminderCount = (policies[index].reminderCount || 0) + 1;
      this.savePolicies(policies);
    }
  },

  renewPolicy(
    id: string, 
    newPolicyNumber: string, 
    newPremiumAmount: number,
    newInsuranceCompany?: string
  ): Policy | null {
    const policies = this.getPolicies();
    const index = policies.findIndex(p => p.id === id);
    if (index === -1) return null;

    const current = policies[index];
    
    // Add current to renewal history
    const historyItem: RenewalHistoryItem = {
      id: `ren-${Date.now()}`,
      previousPolicyNumber: current.policyNumber,
      renewedDate: new Date().toISOString().split('T')[0],
      newExpiryDate: '',
      premiumAmount: current.premiumAmount,
      insuranceCompany: current.insuranceCompany,
    };

    // Calculate new start and expiry date (1 year ahead)
    const oldExpiryDate = new Date(current.policyExpiryDate);
    const newStartDate = new Date(oldExpiryDate);
    newStartDate.setDate(newStartDate.getDate() + 1);

    const newExpiry = new Date(newStartDate);
    newExpiry.setFullYear(newExpiry.getFullYear() + 1);
    newExpiry.setDate(newExpiry.getDate() - 1);

    const newExpiryStr = newExpiry.toISOString().split('T')[0];
    const newStartStr = newStartDate.toISOString().split('T')[0];
    historyItem.newExpiryDate = newExpiryStr;

    policies[index] = {
      ...current,
      policyNumber: newPolicyNumber || current.policyNumber,
      insuranceCompany: newInsuranceCompany || current.insuranceCompany,
      premiumAmount: newPremiumAmount || current.premiumAmount,
      policyStartDate: newStartStr,
      policyExpiryDate: newExpiryStr,
      renewalHistory: [historyItem, ...(current.renewalHistory || [])],
      updatedAt: new Date().toISOString(),
      lastReminderSentAt: undefined,
    };

    this.savePolicies(policies);
    return policies[index];
  },

  getAgentProfile(): AgentProfile {
    try {
      const data = localStorage.getItem(AGENT_STORAGE_KEY);
      if (!data) {
        localStorage.setItem(AGENT_STORAGE_KEY, JSON.stringify(DEFAULT_AGENT_PROFILE));
        return DEFAULT_AGENT_PROFILE;
      }
      return { ...DEFAULT_AGENT_PROFILE, ...JSON.parse(data) };
    } catch {
      return DEFAULT_AGENT_PROFILE;
    }
  },

  saveAgentProfile(profile: AgentProfile): void {
    try {
      localStorage.setItem(AGENT_STORAGE_KEY, JSON.stringify(profile));
    } catch (e) {
      console.error('Failed to save agent profile', e);
    }
  },

  exportBackupJson(): string {
    const data = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      agentProfile: this.getAgentProfile(),
      policies: this.getPolicies(),
    };
    return JSON.stringify(data, null, 2);
  },

  importBackupJson(jsonString: string): { success: boolean; count?: number; error?: string } {
    try {
      const parsed = JSON.parse(jsonString);
      if (!Array.isArray(parsed.policies)) {
        return { success: false, error: 'Invalid backup file format: missing policies array.' };
      }
      this.savePolicies(parsed.policies);
      if (parsed.agentProfile) {
        this.saveAgentProfile(parsed.agentProfile);
      }
      return { success: true, count: parsed.policies.length };
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Unknown JSON parse error';
      return { success: false, error: message };
    }
  },

  exportToCSV(): string {
    const policies = this.getPolicies();
    const headers = [
      'Customer Name',
      'Mobile Phone',
      'Vehicle Number',
      'Vehicle Type',
      'Make & Model',
      'Insurance Company',
      'Policy Number',
      'Policy Type',
      'Premium Amount',
      'Start Date',
      'Expiry Date',
      'NCB %',
      'City',
      'Notes',
    ];

    const rows = policies.map(p => [
      `"${p.customerName.replace(/"/g, '""')}"`,
      `"${p.customerPhone}"`,
      `"${p.vehicleNumber}"`,
      `"${p.vehicleType}"`,
      `"${p.vehicleMakeModel || ''}"`,
      `"${p.insuranceCompany}"`,
      `"${p.policyNumber}"`,
      `"${p.policyType}"`,
      p.premiumAmount,
      p.policyStartDate,
      p.policyExpiryDate,
      p.previousNCB,
      `"${p.customerCity || ''}"`,
      `"${(p.notes || '').replace(/"/g, '""')}"`,
    ]);

    return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  }
};
